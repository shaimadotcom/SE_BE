
<div class="modal fade" id="fileModal"
     tabindex="-1" role="dialog"
     aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-body">
                
                
                
                
                
                
                
                <div class="row">
                    <div class="col-12 text-center mb-3">
                        <a
                            style="min-height: 50px"
                            class="btn-setting btn-scale btn-green text-white d-none d-lg-block"
                            href="https://abdulcpa.securefilepro.com/portal/#/login"
                            target="_blank">Client <br/>File Exchange</a>
                    </div>
                    <div class="col-12 text-center">
                        <a
                            style="min-height: 50px"
                            class="btn-setting btn-scale btn-green text-white d-none d-lg-block"
                            href="https://abdulcpa.securefilepro.com/portal/#/GuestFileExchange/GuestFileExchange/ClientfileUpload.aspx"
                            target="_blank">Guest<br/>File Exchange</a>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Footer starts -->
<footer class="bg-light-gray footer-transform-padding">
    <div class="container">
        <div class="row">
            <div class="col-md-12 col-sm-12 text-center mt-5">
                <p class="copyrights px-0 py-5">&copy; <?php echo e(date('Y')); ?> <?php echo e($site_setting->title); ?>.
                </p>
            </div>
        </div>
    </div>
</footer>
<!-- Footer ends -->
<?php /**PATH E:\wamp64\www\abdulcpa\resources\views/footer.blade.php ENDPATH**/ ?>