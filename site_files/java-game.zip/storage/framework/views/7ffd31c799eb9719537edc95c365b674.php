<!-- JavaScript -->
<script src="<?php echo e(asset('vendor/js/bundle.min.js')); ?>"></script>
<!-- Plugin Js -->
<script src="<?php echo e(asset('vendor/js/jquery.appear.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/js/jquery.fancybox.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/js/owl.carousel.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/js/wow.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/js/jquery.cubeportfolio.min.js')); ?>"></script>
<!-- CUSTOM JS -->
<script src="<?php echo e(asset('vendor/js/contact_us.js')); ?>"></script>
<script src="<?php echo e(asset('interior-designer/js/script.js')); ?>"></script>
<script>
    $(function () {
        new WOW().init();
    });

    function runCarousel() {
        $('.products-carousel').owlCarousel({
            loop: true,
            margin: 10,
            autoplay: true,
            autoplaySpeed: 1,
            nav: false,
            dots: true,
            responsive: {
                0: {
                    items: 1
                },
                600: {
                    items: 1
                },
                1000: {
                    items: 1
                }
            }
        });

        $('.product').hover((e) => {
            $('#' + e.currentTarget.id + " .order-now-btn").addClass('vis-non');
        });

        $('.product').mouseover((e) => {
            $('#' + e.currentTarget.id + " .order-now-btn").removeClass('vis-non');
        })
    }

    setTimeout(()=>{
        runCarousel();
    },2000);


    var i = 1;
    setInterval(() => {
        i++;
        if (i % 4 == 0) {
            i = 1;
        }
        $('.slider').removeClass('active', 2000).removeClass('animate__zoomIn');
        $('.vector').attr('src', '<?php echo e(asset('SOFIA/Vector.png')); ?>');
        $('#slider-' + i).addClass('active', 2000).addClass('animate__zoomIn');
        $('#vector-' + i).attr('src', '<?php echo e(asset('SOFIA/Vector-white.png')); ?>');
        $('.banner-area').addClass('hidden').removeClass('animate__slideInLeft');
        $('#banner-area-' + i).removeClass('hidden').addClass('animate__slideInLeft');
    }, 2000);
</script>
<?php /**PATH E:\wamp64\www\mobile-store\resources\views/js.blade.php ENDPATH**/ ?>