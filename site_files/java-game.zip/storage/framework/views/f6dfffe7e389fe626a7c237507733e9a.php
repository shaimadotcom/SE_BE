<?php $__env->startSection('content'); ?>
    <!-- Page Header -->
    <section class="page_header pb-0 w-100">
        <div class="bg-overlay bg-black opacity-7"></div>
        <div class="container">
            <div class="row">
                <div class="col-md-12 page-content position-relative text-white text-center">
                    <h2 class="mb-2">Blog Posts</h2>
                    <a href="<?php echo e(route('index')); ?>" class="d-inline-block text-white">Home</a>
                    <span><i class="fa fa-angle-double-right font-13"></i> Blog</span>
                </div>
            </div>
        </div>
    </section>
    <!-- Page Header -->

    <!-- Blog starts -->
    <section id="blog" class="bg-light-gray text-left">
        <div class="container">
            <div class="row">
                <!-- Blog Left Listing -->
                <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-6 m-auto">

                        <div class="blog-box heading-space-half">
                            <!-- Blog List Inner -->
                            <div class="blog-listing-inner news_item">
                                <div class="owl-carousel owl-theme owl-split">
                                    <div class="item">
                                        <div class="image hover-effect">
                                            <img src="<?php echo e(Voyager::image($blog->image)); ?>" alt="blog-img">
                                        </div>
                                    </div>
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                </div>

                                <div class="news_desc">
                                    <h3 class="font-weight-normal"><a href="blog-detail.html"
                                                                      class="color-black"><?php echo e($blog->title); ?></a></h3>
                                    <div
                                        class="blog-post mt-25px mb-20px d-flex align-items-center flex-wrap flex-lg-row justify-content-start">
                                        <a href="javascript:void(0)" class="post"><img src="<?php echo e(asset('afnan.jpg')); ?>" alt="image"></a>
                                        <a href="javascript:void(0)" class="color-green font-weight-600 mx-2">Afnan
                                            Abduljaber </a>
                                        <a href="javascript:void(0)" class="color-black mr-2"><i
                                                class="fa fa-calendar color-green mr-2"></i><?php echo e($blog->date); ?></a>
                                        
                                    </div>

                                    <div class="mb-35px color-grey line-height-25px" style="max-height: 100px;min-height: 100px;overflow: hidden">
                                        <?php echo $blog->content; ?>

                                    </div>
                                    <a href="<?php echo e(route('blogs-details',['slug'=>$blog->slug])); ?>"
                                       class="btn-setting btn-scale btn-green text-white">read more</a>
                                </div>
                            </div>
                        </div>
                    </div>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <!-- Blog Widgets -->
            </div>
            <div class="row">
                <div class="col-sm-12 m-auto text-center">
                    <?php echo e($blogs->links()); ?>

                    <!--Pagination-->








                </div>
            </div>

        </div>
    </section>
    <!-- Blog ends -->

<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script>

    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp64\www\abdulcpa\resources\views/blogs.blade.php ENDPATH**/ ?>