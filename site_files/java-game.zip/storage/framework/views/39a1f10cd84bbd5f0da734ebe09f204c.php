<?php
$progs = \App\Models\Program::get();
$sols = \App\Models\Solution::get();
?>
<?php $__env->startPush('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets-new/map/jquery-jvectormap-2.0.5.css')); ?>" type="text/css">
    <style>
        .jvectormap-container {
            border-radius: 10px !important;
        }

    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

    <!-- revolution slider begin -->
    <section id="section-slider" class="fullwidthbanner-container" aria-label="section-slider">
        <div id="slider-revolution">
            <ul>
                <li data-transition="fade" data-slotamount="10" data-masterspeed="200" data-thumb="">
                    <!--  BACKGROUND IMAGE -->
                    <img alt="" class="rev-slidebg" data-bgparallax="0"
                         src="<?php echo e(asset('assets-new/files/slider/2.webp')); ?>">

                    <div class="tp-caption big-white sft" data-x="center" data-y="250" data-width="100vw"
                         data-height="none" data-whitespace="wrap" data-speed="800" data-start="400"
                         data-easing="easeInOutExpo" data-endspeed="450">
                        Prioritizes continuous learning and development
                        <br/>
                        as key to individual and organizational success.
                    </div>

                    <div class="tp-caption title-128 font-weight-bold text-white text-center customin customout start"
                         data-x="center" data-y="350" data-height="none" data-whitespace="wrap"
                         style="width: 100vw"
                         data-customin="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:2;scaleY:2;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
                         data-customout="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0.85;scaleY:0.85;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
                         data-speed="800" data-start="400" data-easing="easeInOutExpo" data-endspeed="400">
                        Systema HR
                    </div>

                    <div class="tp-caption sfb" data-x="center" data-y="490" data-width="none" data-height="none"
                         data-whitespace="nowrap" data-speed="400" data-start="800" data-easing="easeInOutExpo">
                        <a href="<?php echo e(route('programs',['slug'=>$progs[0]->slug])); ?>"
                           class="btn-custom btn-our-portfolio font-weight-bold scroll-to">
                            <?php echo e($progs[0]->title); ?>

                        </a>
                        <div class="small-video small-video-custom">
                            <picture>
                                <source media="(max-width: 991px)" srcset="<?php echo e(asset('assets-new/header.gif')); ?>">
                                <img alt="mubadala-micropill-cop28" src="<?php echo e(asset('assets-new/header.gif')); ?>">
                            </picture>
                        </div>
                    </div>
                </li>
                <li data-transition="fade" data-slotamount="10" data-masterspeed="200" data-thumb="">
                    <!--  BACKGROUND IMAGE -->
                    <img alt="" class="rev-slidebg" data-bgparallax="0"
                         src="<?php echo e(asset('assets-new/files/slider/3.webp')); ?>">

                    <div class="tp-caption big-white sft" data-x="center" data-y="250" data-width="none"
                         data-height="none" data-whitespace="nowrap" data-speed="800" data-start="400"
                         data-easing="easeInOutExpo">
                        Blend innovation with proven strategies to provide cutting-edge
                    </div>

                    <div class="tp-caption title-128 font-weight-bold text-white" data-x="center" data-y="350"
                         data-height="none" data-whitespace="wrap"
                         data-customin="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:2;scaleY:2;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
                         data-customout="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0.85;scaleY:0.85;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
                         data-speed="800" data-start="400" data-easing="easeInOutExpo" data-endspeed="400">
                        Solutions
                    </div>

                    <div class="tp-caption sfb" data-x="center" data-y="490" data-width="none" data-height="none"
                         data-whitespace="nowrap" data-speed="400" data-start="800" data-easing="easeInOutExpo">
                        <a href="<?php echo e(route('programs',['slug'=>$progs[1]->slug])); ?>"
                           class="btn-custom btn-our-portfolio font-weight-bold scroll-to">
                            <?php echo e($progs[1]->title); ?>

                        </a>
                        <div class="small-video small-video-custom">
                            <video autoplay="" playsinline="" loop="" muted="" style="display: block;max-width: 100px;"
                                   src="<?php echo e(asset('assets-new/header2.mp4')); ?>"></video>
                        </div>
                    </div>
                </li>
                <li data-transition="fade" data-slotamount="10" data-masterspeed="200" data-thumb="">
                    <!--  BACKGROUND IMAGE -->
                    <img alt="" class="rev-slidebg" data-bgparallax="0"
                         src="<?php echo e(asset('assets-new/files/slider/4.webp')); ?>">

                    <div class="tp-caption big-white sft" data-x="center" data-y="250" data-width="100vw"
                         data-height="none" data-whitespace="wrap" data-speed="800" data-start="400"
                         data-easing="easeInOutExpo" data-endspeed="450">
                        Prioritizes continuous learning and development
                        <br/>
                        as key to individual and organizational success.
                    </div>

                    <div class="tp-caption title-128 font-weight-bold text-white text-center customin customout start"
                         data-x="center" data-y="350" data-height="none" data-whitespace="wrap"
                         style="width: 100vw"
                         data-customin="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:2;scaleY:2;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
                         data-customout="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0.85;scaleY:0.85;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
                         data-speed="800" data-start="400" data-easing="easeInOutExpo" data-endspeed="400">
                        Systema HR
                    </div>

                    <div class="tp-caption sfb" data-x="center" data-y="490" data-width="none" data-height="none"
                         data-whitespace="nowrap" data-speed="400" data-start="800" data-easing="easeInOutExpo">
                        <a href="<?php echo e(route('programs',['slug'=>$progs[3]->slug])); ?>"
                           class="btn-custom btn-our-portfolio font-weight-bold scroll-to">
                            <?php echo e($progs[3]->title); ?>

                        </a>
                        <div class="small-video small-video-custom">
                            <picture>
                                <source media="(max-width: 991px)" srcset="<?php echo e(asset('assets-new/header.gif')); ?>">
                                <img alt="mubadala-micropill-cop28" src="<?php echo e(asset('assets-new/header.gif')); ?>">
                            </picture>
                        </div>
                    </div>
                </li>
                <li data-transition="fade" data-slotamount="10" data-masterspeed="200" data-thumb="">
                    <!--  BACKGROUND IMAGE -->
                    <img alt="" class="rev-slidebg" data-bgparallax="0"
                         src="<?php echo e(asset('assets-new/files/slider/5.webp')); ?>">

                    <div class="tp-caption big-white sft" data-x="center" data-y="250" data-width="100vw"
                         data-height="none" data-whitespace="wrap" data-speed="800" data-start="400"
                         data-easing="easeInOutExpo" data-endspeed="450">
                        Prioritizes continuous learning and development
                        <br/>
                        as key to individual and organizational success.
                    </div>

                    <div class="tp-caption title-128 font-weight-bold text-white text-center customin customout start"
                         data-x="center" data-y="350" data-height="none" data-whitespace="wrap"
                         style="width: 100vw"
                         data-customin="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:2;scaleY:2;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
                         data-customout="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0.85;scaleY:0.85;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
                         data-speed="800" data-start="400" data-easing="easeInOutExpo" data-endspeed="400">
                        Systema HR
                    </div>

                    <div class="tp-caption sfb" data-x="center" data-y="490" data-width="none" data-height="none"
                         data-whitespace="nowrap" data-speed="400" data-start="800" data-easing="easeInOutExpo">
                        <a href="<?php echo e(route('solutions',['slug'=>$sols[1]->slug])); ?>"
                           class="btn-custom btn-our-portfolio font-weight-bold scroll-to">
                            <?php echo e($sols[1]->title); ?>

                        </a>
                        <div class="small-video small-video-custom">
                            <picture>
                                <source media="(max-width: 991px)" srcset="<?php echo e(asset('assets-new/header.gif')); ?>">
                                <img alt="mubadala-micropill-cop28" src="<?php echo e(asset('assets-new/header.gif')); ?>">
                            </picture>
                        </div>
                    </div>
                </li>
                <li data-transition="fade" data-slotamount="10" data-masterspeed="200" data-thumb="">
                    <!--  BACKGROUND IMAGE -->
                    <img alt="" class="rev-slidebg" data-bgparallax="0"
                         src="<?php echo e(asset('assets-new/files/slider/6.webp')); ?>">

                    <div class="tp-caption big-white sft" data-x="center" data-y="250" data-width="none"
                         data-height="none" data-whitespace="nowrap" data-speed="800" data-start="400"
                         data-easing="easeInOutExpo">
                        Blend innovation with proven strategies to provide cutting-edge
                    </div>

                    <div class="tp-caption title-128 font-weight-bold text-white" data-x="center" data-y="350"
                         data-height="none" data-whitespace="wrap"
                         data-customin="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:2;scaleY:2;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
                         data-customout="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0.85;scaleY:0.85;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
                         data-speed="800" data-start="400" data-easing="easeInOutExpo" data-endspeed="400">
                        Solutions
                    </div>

                    <div class="tp-caption sfb" data-x="center" data-y="490" data-width="none" data-height="none"
                         data-whitespace="nowrap" data-speed="400" data-start="800" data-easing="easeInOutExpo">
                        <a href="<?php echo e(route('solutions',['slug'=>$sols[2]->slug])); ?>"
                           class="btn-custom btn-our-portfolio font-weight-bold scroll-to">
                            <?php echo e($sols[2]->title); ?>

                        </a>
                        <div class="small-video small-video-custom">
                            <video autoplay="" playsinline="" loop="" muted="" style="display: block;max-width: 100px;"
                                   src="<?php echo e(asset('assets-new/header2.mp4')); ?>"></video>
                        </div>
                    </div>
                </li>
            </ul>
        </div>
    </section>
    <!-- revolution slider close -->

    <section
        class="comp-type-image --with-video --margin-bottom-sm-50 --margin-bottom-xs-80 --margin-top-xs-80 --margin-bottom-md-50 --margin-bottom-sm-50">
        <div class="padding-left-container">
            <div class="type-image-inner">
                <div class="left-type-image">
                    <div class="desc">
                        <div class="desc">
                            At Systema HR, we are committed to driving transformative learning experiences, empowering
                            individuals and organizations to reach their pinnacle of excellence.
                        </div>
                    </div>
                </div>
                <div class="right-type-image">
                    <div class="stats comp-img">
                        <div class="video" data-video-block="" data-type-video="vimeo"
                             data-video-desktop="<?php echo e(asset('assets-new/105.mp4')); ?>">
                            <div class="video__inner">
                                <div class="video-box">
                                    <video class="vimeo-video" autoplay="" playsinline="" loop="" muted=""
                                           src="<?php echo e(asset('assets-new/105.mp4')); ?>"></video>
                                </div>
                            </div>
                        </div>
                        <div class="comp-img__outside --has-overlay">
                            <picture>
                                <source media="(max-width: 991px)" srcset="<?php echo e(asset('assets-new/105.png')); ?>">
                                <img alt="1015-desktop-en" src="<?php echo e(asset('assets-new/105.png')); ?>"
                                     class=" --lazy-success">
                            </picture>
                        </div>
                    </div>
                    <div class="content-number">
                        <div class="desc-number">
                            
                        </div>
                        
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section id="section-text">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-5 offset-md-1 mb-sm-30 text-center wow fadeInRight">
                    <div class="de-images">
                        <img class="di-small img-6 wow fadeIn" src="<?php echo e(asset('assets-new/files/partner/6.webp')); ?>"
                             alt=""/>
                        <img class="di-small-2 img-8" src="<?php echo e(asset('assets-new/files/partner/8.webp')); ?>" alt=""/>
                        <img class="img-fluid img-7 wow fadeInRight" data-wow-delay=".25s"
                             src="<?php echo e(asset('assets-new/files/partner/7.webp')); ?>" alt=""/>
                    </div>
                </div>

                <div class="col-lg-5 offset-md-1 partners wow fadeInLeft" data-wow-delay="0s">
                    <h2>Your Partner for<br><span class="id-color">Transformative Learning and Development</span></h2>
                    <p>
                        At Systema HR, we stand as your dedicated partner, guiding you towards unparalleled success
                        through transformative learning experiences. Our innovative solutions, tailored to your unique
                        needs, ensure sustained growth and excellence in today's ever-evolving landscape. Trust us to be
                        your beacon of support on the journey towards achieving your goals.
                    </p>

                    <a href="<?php echo e(route('about-us')); ?>" class="btn-custom font-weight-bold">Read More</a>
                </div>
            </div>
        </div>
    </section>

    <!-- section begin -->
    <section id="section-about">
        <div class="wm wm-border dark wow fadeInDown">01</div>
        <div class="container">
            <div class="row">
                <div class="col-md-12 text-center wow fadeInUp">
                    <h1>Our Programs</h1>
                    <div class="separator"><span><i class="fa fa-square"></i></span></div>
                    <div class="spacer-single"></div>
                </div>

                <?php $__currentLoopData = \App\Models\Program::get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-3 m-auto mt-3 wow fadeInRight text-center">
                        <a href="<?php echo e(route('programs',['slug'=>$p->slug])); ?>">
                            <img src="<?php echo e(asset('assets-new/files/programs/'.$key.'.png')); ?>"
                                 style="width: 150px;"
                                 class="img-responsive img-shadow" alt="">
                        </a>
                        <div class="spacer20"></div>
                        <h3 class="text-center"><span class="id-color">0<?php echo e($key+1); ?></span> <?php echo e($p->title); ?></h3>
                        
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
    <!-- section close -->


    <!-- section begin -->
    <section id="section-testimonial-architecture"
             data-bgimage="url(<?php echo e(asset('assets-new/files/reviews/1.png')); ?>) fixed">
        <div class="container">
            <div class="row">

                <div class="col-md-8 offset-md-2">

                    <div id="testimonial-carousel-single" class="owl-carousel owl-theme wow fadeInUp">
                        <blockquote class="testimonial-big">
                            <span class="title">Inspirational Learning Journeys</span>
                            "Systema HR has transformed our approach to Learning and Development, turning each
                            opportunity into a stepping stone for unparalleled achievement. Their commitment to
                            continuous learning is both inspiring and effective. Their adaptability in a dynamic global
                            landscape, blended with innovative strategies, has empowered our organization to thrive."

                            
                        </blockquote>

                        <blockquote class="testimonial-big">
                            <span class="title">Leaders in Evolutionary Solutions</span>
                            "As a leading figure in the industry, Systema HR's track record of impactful transformations
                            and sustained growth speaks volumes. Their team of seasoned professionals not only
                            understands our unique needs but also crafts tailor-made solutions that pave the way for
                            success. Trust, integrity, and a shared passion for continual growth define their legacy."
                            
                        </blockquote>

                        <blockquote class="testimonial-big">
                            <span class="title">Extraordinary Impact, Enduring Excellence</span>
                            "Our experience with Systema HR has been nothing short of extraordinary. Their commitment to
                            reshaping the Learning and Development terrain is evident in the enduring excellence they
                            bring to every project. Systema HR is not just a provider; they are architects of positive
                            change, consistently evolving their methods to offer cutting-edge solutions that fuel
                            success in today's dynamic world."
                            
                        </blockquote>
                    </div>

                </div>

            </div>

        </div>
    </section>
    <!-- section close -->

    <!-- section begin -->
    <section id="call-to-action" class="bg-color text-dark call-to-action padding40" aria-label="cta">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-8 col-md-7">
                    <h3 class="size-2 no-margin">Do You Need A
                        <Solution></Solution>
                        ?
                    </h3>
                </div>

                <div class="col-lg-4 col-md-5 text-right">
                    
                    <a href="<?php echo e(route('contact-us')); ?>" class="btn-black">Contact Us Now</a>
                </div>
            </div>
        </div>
    </section>
    <!-- logo carousel section close -->

    
    
    
    
    
    
    
    

    
    
    
    
    

    

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

    

    
    
    
    

    <!-- section begin -->
    <section id="section-highlight">
        <div class="wm wm-border dark wow fadeInDown ">02</div>
        <div class="container">
            <div class="row">
                <div class="col-md-6 offset-md-3 text-center wow fadeInUp">
                    <h1>Solutions</h1>
                    <div class="separator"><span><i class="fa fa-square"></i></span></div>
                    <div class="spacer-single"></div>

                </div>


                <?php $__currentLoopData = \App\Models\Solution::get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-4 m-auto mt-3 wow fadeInRight text-center">
                        <a href="<?php echo e(route('solutions',['slug'=>$s->slug])); ?>">
                            <img src="<?php echo e(asset('assets-new/files/solutions/'.$key.'.png')); ?>"
                                 style="width: 150px;"
                                 class="img-responsive img-shadow" alt="">
                        </a>
                        <div class="spacer20"></div>
                        <h3 class="text-center"><span class="id-color">0<?php echo e($key+1); ?></span> <?php echo e($s->title); ?></h3>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
    <!-- section close -->



    <section class="p-0">
        <div class="wm wm-border dark wow fadeInDown ">03</div>
        <div class="container">
            <div class="row">
                <div class="col-md-6 offset-md-3 text-center wow fadeInUp">
                    <h1>Our Partners</h1>
                    <div class="separator"><span><i class="fa fa-square"></i></span></div>
                </div>

                <div class="spacer-single"></div>

                <div class="col-md-12 mt-5 wow fadeInRight" data-wow-delay="0s">
                    <div class="owl-carousel reviews-carousel">
                        <?php for($i=1;$i<=14;$i++): ?>
                            <div class="text-center">
                                <img src="<?php echo e(asset('assets-new/files/clients logos/'.$i.'.png')); ?>"
                                     style="max-width: 125px !important;">
                            </div>
                        <?php endfor; ?>
                    </div>
                </div>

            </div>
        </div>
    </section>

    <section id="section-text">
        <div class="wm wm-border dark wow fadeInDown ">04</div>
        <div class="container">
            <div class="row align-items-center">
                <div class="row">
                    <div class="col-md-6 offset-md-3 text-center wow fadeInUp">
                        <h1>Our Locations</h1>
                        <div class="separator"><span><i class="fa fa-square"></i></span></div>
                    </div>

                    <div class="spacer-single"></div>
                </div>
                <div class="row">
                    <div class="col-md-12 mt-3" style="border-radius: 20px;">
                        <div id="world-map-markers"
                             style="width: 100%;height: 300px;"></div>
                    </div>
                </div>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script src="<?php echo e(asset('assets-new/map/jquery-jvectormap-2.0.5.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets-new/map/jquery-jvectormap-world-mill.js')); ?>"></script>
    <script>
        $(function () {
            const isMobile = /iPhone|iPad|iPod|Android/i.test(navigator.userAgent);
            if (isMobile) {
                $('#world-map-markers').vectorMap({
                    map: 'world_mill',
                    scaleColors: ['#C8EEFF', '#0d6efd'],
                    normalizeFunction: 'polynomial',
                    hoverOpacity: 0.7,
                    hoverColor: false,
                    focusOn: {
                        x: 0.59,
                        y: 0.5,
                        scale: 10
                    },
                    markerStyle: {
                        initial: {
                            fill: 'rgba(13,110,253,0.68)',
                            stroke: '#383f47',
                            r: 10
                        }
                    },
                    backgroundColor: '#063172cc',
                    markers: [
                        {latLng: [24.4539, 54.3773], name: 'Abu Dhabi',},
                        {latLng: [24.7136, 46.6753], name: 'Riyadh'},
                    ]
                });
            } else {
                $('#world-map-markers').vectorMap({
                    map: 'world_mill',
                    scaleColors: ['#C8EEFF', '#0d6efd'],
                    normalizeFunction: 'polynomial',
                    hoverOpacity: 0.7,
                    hoverColor: false,
                    focusOn: {
                        x: 0.6,
                        y: 0.5,
                        scale: 10
                    },
                    markerStyle: {
                        initial: {
                            fill: 'rgba(13,110,253,0.68)',
                            stroke: '#383f47',
                            r: 10
                        }
                    },
                    backgroundColor: '#063172cc',
                    markers: [
                        {latLng: [24.4539, 54.3773], name: 'Abu Dhabi',},
                        {latLng: [24.7136, 46.6753], name: 'Riyadh'},
                    ]
                });
            }


        });

        $(document).ready(function () {
            $(".reviews-carousel").owlCarousel({
                center: false,
                items: 6,
                loop: true,
                dots: true,
                autoplay: true,
                autoplaySpeed: 1000,
                margin: 0,
                responsive: {
                    1000: {
                        items: 6
                    },
                    600: {
                        items: 4
                    },
                    0: {
                        items: 2
                    }
                }
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp64\www\systemahr\resources\views/index.blade.php ENDPATH**/ ?>