<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pk=>$p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
        $image = json_decode($p->images);
        ?>
    <div class="col-md-3">
        <div class="product" id="product-<?php echo e($skip+$pk+1); ?>">
            <div class="owl-carousel products-carousel owl-theme">
                <?php if(is_array($image)): ?>
                    <?php $__currentLoopData = $image; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $im): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="item"><img

                                src="<?php echo e(Voyager::image($im)); ?>"/></div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </div>
            <div class="product-details">
                <div class="line1">
                    <div class="product-brand">
                        <?php echo e($p->brand?$p->brand->title:''); ?>

                    </div>
                    <div class="product-state <?php echo e($p->in_stock==1?'in':'out'); ?>">

                    </div>
                </div>
                <div class="product-name">
                    <?php echo e($p->title); ?>

                </div>
                <div class="product-description">
                    <?php echo substr($p->description,0,165); ?> <?php if(strlen($p->description)>165): ?> ... <?php endif; ?>
                </div>
            </div>
            <div class="product-order">
                <a class="order-now-btn vis-non" href="#contact">
                    order now
                </a>
            </div>
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH E:\wamp64\www\mobile-store\resources\views/products.blade.php ENDPATH**/ ?>