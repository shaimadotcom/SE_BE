<link rel="icon" type="image/x-icon" href="/SOFIA/icons/logo footer@2x.png">
<!-- Bundle -->
<link rel="stylesheet" href="<?php echo e(asset('vendor/css/bundle.min.css')); ?>">
<!-- Plugin Css -->
<link href="<?php echo e(asset('vendor/css/LineIcons.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('vendor/css/jquery.fancybox.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('vendor/css/owl.carousel.min.css')); ?>" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.css"
      rel="stylesheet"/>
<link href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css"
      rel="stylesheet"/>
<link
    rel="stylesheet"
    href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"
/>
<link href="<?php echo e(asset('vendor/css/wow.css')); ?>" rel="stylesheet">
<link rel="stylesheet" href="<?php echo e(asset('vendor/css/cubeportfolio.min.css')); ?>">
<link href="<?php echo e(asset('interior-designer/css/line-awesome.min.css')); ?>" rel="stylesheet">
<!-- Style Sheet -->
<link href="<?php echo e(asset('interior-designer/css/style.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('interior-designer/css/custom.css')); ?>" rel="stylesheet">
<?php /**PATH E:\wamp64\www\mobile-store\resources\views/css.blade.php ENDPATH**/ ?>