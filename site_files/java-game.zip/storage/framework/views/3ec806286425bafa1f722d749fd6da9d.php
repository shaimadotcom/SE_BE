<!-- Header start -->
<header>
    <nav class="navbar navbar-top-default navbar-expand-lg static-nav transparent-bg nav-bottom-line">
        <div class="container">
            <a class="logo" href="javascript:void(0)">
                <img src="<?php echo e(asset('consulting/img/logo.png')); ?>" alt="logo" title="Logo" class="logo-default">
                <img src="<?php echo e(asset('consulting/img/logo2.png')); ?>" alt="logo" title="Logo" class="logo-scrolled">
            </a>
            <div class="collapse navbar-collapse d-none d-lg-block">
                <ul class="nav navbar-nav ml-auto mr-4">
                    <li class="nav-item"><a href="<?php echo e(route('index')); ?>#home" class="<?php echo e(\Illuminate\Support\Facades\Route::currentRouteName()=='index'?'scroll':''); ?> nav-link">home</a></li>
                    <li class="nav-item"><a href="<?php echo e(route('index')); ?>#aboutus" class="<?php echo e(\Illuminate\Support\Facades\Route::currentRouteName()=='index'?'scroll':''); ?> nav-link">about us</a></li>
                    <li class="nav-item"><a href="<?php echo e(route('index')); ?>#testimonials" class="<?php echo e(\Illuminate\Support\Facades\Route::currentRouteName()=='index'?'scroll':''); ?> nav-link">Testimonials</a></li>
                    <li class="nav-item"><a href="<?php echo e(route('index')); ?>#request" class="<?php echo e(\Illuminate\Support\Facades\Route::currentRouteName()=='index'?'scroll':''); ?> nav-link">Services</a></li>
                    
                    <li class="nav-item"><a href="<?php echo e(route('index')); ?>#blog" class="<?php echo e(\Illuminate\Support\Facades\Route::currentRouteName()=='index'?'scroll':''); ?> nav-link">blog</a></li>
                    <li class="nav-item"><a href="<?php echo e(route('index')); ?>#contact" class="<?php echo e(\Illuminate\Support\Facades\Route::currentRouteName()=='index'?'scroll':''); ?> nav-link">contact</a></li>
                </ul>
            </div>

            <a class="btn-setting btn-scale btn-green text-white d-none d-lg-block"
               style="cursor: pointer;"
               data-toggle="modal" data-target="#fileModal">
                File Exchange</a>


            <!-- side menu open button -->
            <a class="menu_bars d-inline-block menu-bars-setting" id="sidemenu_toggle">
                <div class="menu-lines">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
            </a>
        </div>
    </nav>
    <div class="side-menu">
        <div class="inner-wrapper nav-icon">
            <span class="btn-close" id="btn_sideNavClose"></span>
            <nav class="side-nav w-100">
                <div class="navbar-nav">
                    <a href="<?php echo e(route('index')); ?>#home" class="<?php echo e(\Illuminate\Support\Facades\Route::currentRouteName()=='index'?'scroll':''); ?> nav-link">home</a>
                    <a href="<?php echo e(route('index')); ?>#aboutus" class="<?php echo e(\Illuminate\Support\Facades\Route::currentRouteName()=='index'?'scroll':''); ?> nav-link">about us</a>
                    <a href="<?php echo e(route('index')); ?>#testimonials" class="<?php echo e(\Illuminate\Support\Facades\Route::currentRouteName()=='index'?'scroll':''); ?> nav-link">Testimonials</a>
                    <a href="<?php echo e(route('index')); ?>#request" class="<?php echo e(\Illuminate\Support\Facades\Route::currentRouteName()=='index'?'scroll':''); ?> nav-link">Services</a>
                    
                    <a href="<?php echo e(route('index')); ?>#blog" class="<?php echo e(\Illuminate\Support\Facades\Route::currentRouteName()=='index'?'scroll':''); ?> nav-link">blog</a>
                    <a href="<?php echo e(route('index')); ?>#contact" class="<?php echo e(\Illuminate\Support\Facades\Route::currentRouteName()=='index'?'scroll':''); ?> nav-link">contact</a>
                    <a class="menu-line"><i class="fa fa-angle-right font-14" aria-hidden="true"></i></a>
                </div>
            </nav>

            <div class="side-footer text-white w-100">
                <ul class="social-icons-simple">
                    <li class="side-menu-icons"><a href="<?php echo e($site_setting->facebook); ?>"><i
                                class="fab fa-facebook-f color-white"></i> </a></li>
                    <li class="side-menu-icons"><a href="<?php echo e($site_setting->instagram); ?>"><i
                                class="fab fa-instagram color-white"></i> </a></li>
                    <li class="side-menu-icons"><a href="<?php echo e($site_setting->linkedin); ?>"><i class="fab fa-linkedin color-white"></i>
                        </a></li>
                    <li class="side-menu-icons"><a href="<?php echo e($site_setting->tiktok); ?>">
                            <svg xmlns="http://www.w3.org/2000/svg"
                                 style="width: 11px;filter: invert(1);"
                                 viewBox="0 0 448 512">
                                <path
                                    d="M448 209.9a210.1 210.1 0 0 1 -122.8-39.3V349.4A162.6 162.6 0 1 1 185 188.3V278.2a74.6 74.6 0 1 0 52.2 71.2V0l88 0a121.2 121.2 0 0 0 1.9 22.2h0A122.2 122.2 0 0 0 381 102.4a121.4 121.4 0 0 0 67 20.1z"/>
                            </svg>
                        </a></li>
                </ul>
                <p class="text-white">&copy; <?php echo e(date('Y')); ?> Abdul CPA.</p>
            </div>
        </div>
    </div>
    <a id="close_side_menu" href="javascript:void(0);"></a>
    <!--Side Menu-->
</header>
<!-- Header end -->
<?php /**PATH E:\wamp64\www\abdulcpa\resources\views/header.blade.php ENDPATH**/ ?>