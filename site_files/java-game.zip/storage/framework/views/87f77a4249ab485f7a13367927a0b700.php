<!-- Start preloader -->
<div class="loader-bg">
    <div id="building">
        <div id="blocks">
            <div class="b" id="b1"></div>
            <div class="b" id="b2"></div>
            <div class="b" id="b3"></div>
            <div class="b" id="b4"></div>
        </div>
    </div>
</div>
<!-- End Preloader -->

<div class="top-header">
    <?php echo $site_setting->black_header_text; ?>

</div>
<!-- Start Header -->
<header>
    <!--Navigation-->
    <nav class="navbar navbar-top-default navbar-expand-lg navbar-simple nav-line">
        <a href="javascript:void(0)" class="sidemenu_btn" id="sidemenu_toggle">
            <span></span>
            <span></span>
            <span></span>
        </a>
        <div class="container-fluid">
            <a href="<?php echo e(url('')); ?>" title="Logo" class="logo">
                <!--Logo Default-->
                <img src="<?php echo e(Voyager::image($site_setting->header_logo)); ?>" alt="logo" class="logo-dark ml-lg-5 mr-lg-2">
            </a>
            <!--Nav Links-->
            <div class="collapse navbar-collapse " id="megaone">
                <div class="navbar-nav mr-auto">
                    <a class="nav-link scroll" href="#about">About</a>
                    <a class="nav-link scroll" href="#products">Products</a>
                    <a class="nav-link scroll" href="#contact">Contact Us</a>
                </div>
            </div>
            <!--Side Menu Button-->
            <div class="nav-social text-white d-flex justify-content-center">
                <ul class="social-icons-simple">
                    <li class="header-item">
                        <div class="header-item-icon">
                            <div>
                                <img src="<?php echo e(asset('SOFIA/icons/email footer@2x.png')); ?>"/>
                            </div>
                        </div>
                        <div class="header-item-value">
                            <div class="type">
                                <div>
                                    Email
                                </div>
                            </div>
                            <div class="header-item-value-1">
                                <span class="pointer"
                                      onclick="window.location='mailto:<?php echo e($site_setting->email); ?>'"><?php echo e($site_setting->email); ?></span>
                            </div>
                        </div>
                    </li>
                    <li class="header-item">
                        <div class="header-item-icon">
                            <div>
                                <img src="<?php echo e(asset('SOFIA/icons/phone@2x.png')); ?>"/>
                            </div>
                        </div>
                        <div class="header-item-value">
                            <div class="type">
                                <div>
                                    CALL US NOW
                                </div>
                            </div>
                            <div class="header-item-value-1">
                                <span class="pointer"
                                      onclick="window.location='tel:<?php echo e($site_setting->phone); ?>'"><?php echo e($site_setting->phone); ?></span>
                            </div>
                        </div>
                    </li>
                </ul>
            </div>
        </div>
        <!--Social Icons-->
    </nav>
    <!--Side Nav-->
    <div class="side-menu hidden">
        <div class="inner-wrapper">
            <span class="btn-close" id="btn_sideNavClose"><i></i><i></i></span>
            <nav class="side-nav w-100">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link scroll" href="#about">About</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link scroll" href="#products">Products</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link scroll" href="#contact">Contact Us</a>
                    </li>
                </ul>
            </nav>

            <div class="side-footer text-white w-100">
                <ul class="social-icons-simple sip">
                    <li><a class="facebook-bg-hvr" href="<?php echo e($site_setting->facebook); ?>"><i class="fab fa-facebook-f"></i></a>
                    </li>
                    <li><a class="twitter-bg-hvr" href="<?php echo e($site_setting->instagram); ?>"><i
                                class="fab fa-instagram"></i></a></li>
                    <li><a class="twitter-bg-hvr" href="<?php echo e($site_setting->twitter); ?>"><i class="fab fa-twitter"></i></a>
                    </li>
                    <li><a class="twitter-bg-hvr" href="<?php echo e($site_setting->whatsapp); ?>"><i class="fab fa-whatsapp"></i></a>
                    </li>
                </ul>
                <p class="sidemenu-des">© Sofia. All Rights Reserved.</p>
            </div>
        </div>
    </div>
    <a id="close_side_menu" href="javascript:void(0);"></a>
    <!-- End side menu -->
</header>
<!-- End Header -->
<?php /**PATH E:\wamp64\www\mobile-store\resources\views/header.blade.php ENDPATH**/ ?>