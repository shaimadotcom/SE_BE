<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <link rel="icon" href="<?php echo e(asset('assets/images/icon.png')); ?>" type="image/gif" sizes="16x16">
    <title>Systema HR</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Systema HR">
    <meta name="keywords" content="Systema, Hr">
    <meta name="author" content="">

    <?php echo $__env->make('css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldPushContent('css'); ?>
</head>

<body id="homepage">

<div id="wrapper">

    <?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <?php echo $__env->yieldContent('under-header'); ?>

    <!-- content begin -->
    <div id="content" class="no-bottom no-top">
        <?php echo $__env->yieldContent('content'); ?>
        <?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</div>

<?php echo $__env->make('js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldPushContent('js'); ?>
</body>

</html>
<?php /**PATH E:\wamp64\www\systemahr\resources\views/app.blade.php ENDPATH**/ ?>