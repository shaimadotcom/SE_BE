












<?php /**PATH E:\wamp64\www\mobile-store\vendor\tcg\voyager\src/../resources/views/partials/app-footer.blade.php ENDPATH**/ ?>