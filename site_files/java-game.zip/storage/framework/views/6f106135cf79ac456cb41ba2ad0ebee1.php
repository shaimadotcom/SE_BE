<?php $__env->startPush('meta'); ?>

    <!--  Essential META Tags -->
    <meta property="og:title" content="<?php echo e($blog->title); ?>">
    <meta property="og:type" content="article"/>
    <meta property="og:image" content="<?php echo e(Voyager::image($blog->image)); ?>">
    <meta property="og:url" content="<?php echo e(route('blogs-details',['slug'=>$blog->slug])); ?>">
    <meta name="twitter:card" content="summary_large_image">

    <!--  Non-Essential, But Recommended -->
    <meta property="og:description" content="<?php echo e($blog->shrot_description); ?>">
    <meta property="og:site_name" content="AbdulCPA">
    <meta name="twitter:image:alt" content="<?php echo e($blog->title); ?>">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <!-- Page Header -->
    <section class="page_header pb-0 w-100">
        <div class="bg-overlay bg-black opacity-7"></div>
        <div class="container">
            <div class="row">
                <div class="col-md-12 page-content position-relative text-white text-center">
                    <h2 class="mb-2">Blog Posts</h2>
                    <a href="<?php echo e(route('index')); ?>" class="d-inline-block text-white">Home</a> <span><i
                            class="fa fa-angle-double-right font-13"></i> Blog</span>
                </div>
            </div>
        </div>
    </section>
    <!-- Page Header -->

    <!-- Blog starts -->
    <section id="blog" class="bg-light-gray text-left">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <!-- Blog List Inner -->
                    <div class="blog-listing-inner heading-space-half">
                        <div class="image hover-effect">
                            <img src="<?php echo e(Voyager::image($blog->image)); ?>" alt="blog-img">
                        </div>
                    </div>
                </div>
                <!-- Blog Left Listing -->
                <div class="col-lg-12">
                    <div class="blog-box heading-space-half m-md-0">
                        <!-- Blog List Inner -->
                        <div class="blog-listing-inner news_item">
                            <div class="news_desc">
                                <h3 class="font-weight-normal"><a href="javascript:void(0)"
                                                                  class="color-black"><?php echo e($blog->title); ?></a></h3>
                                <div
                                    class="blog-post mt-25px mb-20px d-flex align-items-center flex-wrap flex-lg-row justify-content-start">
                                    <a href="javascript:void(0)" class="post"><img src="<?php echo e(asset('afnan.jpg')); ?>"
                                                                                   alt="image"></a>
                                    <a href="javascript:void(0)" class="color-green font-weight-600 mx-2">Afnan
                                        Abduljaber</a>
                                    <a href="javascript:void(0)" class="color-black mr-2"><i
                                            class="fa fa-calendar color-green mr-2"></i><?php echo e($blog->date); ?></a>
                                    
                                </div>
                                <div class="mb-35px color-grey line-height-25px">
                                    <?php echo e($blog->content); ?>

                                </div>
                                <blockquote class="mb-50px blockquote font-italic font-weight-light color-black"><i
                                        class="fa fa-quote-left font-20 pr-2"></i>
                                    Afnan is a Certified Public Accountant and hold a Master’s in Accounting degree from
                                    Wayne State University. Afnan achieved a 4.00/4.00 GPA in four on-campus Graduate
                                    Accounting Courses in one semester.
                                </blockquote>
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                

                                
                                
                                
                                
                                
                                
                                

                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Blog ends -->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script>

    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp64\www\abdulcpa\resources\views/blogs-details.blade.php ENDPATH**/ ?>