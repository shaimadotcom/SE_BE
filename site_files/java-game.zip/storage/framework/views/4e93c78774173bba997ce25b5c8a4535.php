<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Meta Tags -->
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1, shrink-to-fit=no" name="viewport">
    <!-- Author -->
    <meta name="author" content="Sofia">
    <!-- Description -->
    <meta name="description"
          content="<?php echo e($site_setting->description); ?>">
    <meta name="keywords"
          content="<?php echo e($site_setting->keywords); ?>">
    <!-- Page Title -->
    <title> <?php echo e($site_setting->title); ?></title>

    <!-- Open Graph / Facebook -->
    <meta property="og:type" content="website"/>
    <meta property="og:url" content="<?php echo e(url('')); ?>"/>
    <meta property="og:title" content="<?php echo e($site_setting->title); ?>"/>
    <meta property="og:description" content="<?php echo e($site_setting->description); ?>"/>
    <meta property="og:image" content="<?php echo e(Voyager::image($site_setting->header_logo)); ?>"/>

    <!-- Twitter -->
    <meta property="twitter:card" content="summary_large_image"/>
    <meta property="twitter:url" content="<?php echo e(url('')); ?>"/>
    <meta property="twitter:title" content="<?php echo e($site_setting->title); ?>"/>
    <meta property="twitter:description" content="<?php echo e($site_setting->description); ?>"/>
    <meta property="twitter:image" content="<?php echo e(Voyager::image($site_setting->header_logo)); ?>"/>


    <?php echo $__env->make('css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldPushContent('css'); ?>
</head>
<body data-offset="90" data-spy="scroll" data-target=".navbar">

<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->yieldContent('content'); ?>

<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldPushContent('js'); ?>
</body>
</html>
<?php /**PATH E:\wamp64\www\mobile-store\resources\views/app.blade.php ENDPATH**/ ?>