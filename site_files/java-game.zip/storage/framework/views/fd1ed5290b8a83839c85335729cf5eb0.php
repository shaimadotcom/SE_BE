<?php $__env->startPush('css'); ?>


<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

    <?php
    $slider = \App\Models\Product::where('status', 1)->where('show_in_banner', 1)->orderBy('id', 'desc')->skip(0)->take(3)->get();
    ?>
        <!-- Start banner -->
    <section class="banner-sec banner-image" id="banner">
        <div class="container">
            <div class="row">
                <div class="col-lg-4 d-flex align-items-center justify-content-center">
                    <?php $__currentLoopData = $slider; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="banner-area <?php echo e($key>0?'hidden':''); ?> animate__animated" id="banner-area-<?php echo e($key+1); ?>">
                            <?php if($s->banner_badge): ?>
                                <a href="#" class="badge badge-danger"
                                   style="background: <?php echo e($s->banner_badge_color); ?>;"><?php echo e($s->banner_badge); ?></a>
                            <?php endif; ?>
                            <h2 class="banner-heading">
                                <?php echo e($s->banner_title); ?>

                            </h2>
                            <h4 class="banner-des"><?php echo e($s->banner_description); ?></h4>
                            <a href="#about" class="btn primary-btn">Contact us</a>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="col-md-8 show-desktop">
                    <div class="row">
                        <?php $__currentLoopData = $slider; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                $image = json_decode($s->images);
                                ?>
                            <div class="col-md-4">
                                <div id="slider-<?php echo e($key+1); ?>" class="slider animate__animated <?php echo e($key==0?'active':''); ?>">
                                    <div class="line1"></div>
                                    <div class="line2">
                                        <div style="">
                                            <img class="vector" id="vector-<?php echo e($key+1); ?>"
                                                 src="<?php echo e($key==0?asset('SOFIA/Vector-white.png'):asset('SOFIA/Vector.png')); ?>"
                                                 width="80%">
                                        </div>
                                    </div>
                                    <div class="line3">
                                        <div class="slider-brand">
                                            <?php echo e($s->brand?$s->brand->title:''); ?>

                                        </div>
                                        <div class="slider-title">
                                            <?php echo e($s->title); ?>

                                        </div>
                                        <div class="slider-desc">
                                            <?php echo e(substr($s->description,0,80)); ?> <?php if(strlen($s->description)>80): ?>
                                                ...
                                            <?php endif; ?>
                                        </div>
                                        <div class="separator"></div>
                                        <div class="p-state <?php echo e($s->in_stock==1?'in':'out'); ?>">
                                            <?php echo e($s->in_stock==1?'In Stock':'Out of Stock'); ?>

                                        </div>
                                        <div class="line4">
                                            <div class="line5">
                                                <a class="get-quote">
                                                    Get Quote
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <img class="top-img"
                                         src="<?php echo e(Voyager::image($image[0])); ?>"/>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- End banner -->

    <section class="services">
        <div class="container">
            <div class="row text-black">
                <div class="col-md-12">
                    <h3 class="text-center mt-3 mb-3">Privacy Policy</h3>
                    <?php echo $content->privacy_policy; ?>

                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp64\www\mobile-store\resources\views/privacy-policy.blade.php ENDPATH**/ ?>