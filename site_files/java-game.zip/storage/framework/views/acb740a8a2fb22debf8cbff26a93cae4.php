
<section class="end">
    <div class="row mb-3 footer">
        <div class="col-lg-4">
            <div class="footer-social">
                <ul class="list-unstyled">
                    <li>
                        <a class="wow fadeInUp" data-wow-delay=".1s" href="<?php echo e($site_setting->facebook); ?>">
                            <img src="<?php echo e(asset('SOFIA/icons/facebook@2x.png')); ?>">
                        </a>

                    </li>
                    <li>
                        <a class="wow fadeInUp" data-wow-delay=".1s" href="<?php echo e($site_setting->instagram); ?>">
                            <img src="<?php echo e(asset('SOFIA/icons/instagram@2x.png')); ?>">
                        </a>
                    </li>
                    <li>
                        <a class="wow fadeInUp" data-wow-delay=".1s" href="<?php echo e($site_setting->twitter); ?>">
                            <img src="<?php echo e(asset('SOFIA/icons/twitter@2x.png')); ?>">
                        </a></li>
                    <li>
                        <a class="wow fadeInUp" data-wow-delay=".1s" href="<?php echo e($site_setting->whatsapp); ?>">
                            <img src="<?php echo e(asset('SOFIA/icons/whatsapp@2x.png')); ?>">
                        </a></li>
                </ul>
            </div>
        </div>
        <!--Text-->
        <div class="col-lg-4 text-center">
            <img src="<?php echo e(Voyager::image($site_setting->footer_logo)); ?>" width="75">
        </div>

        <div class="col-lg-4 footer-btns">
            <div class="mt-4 text-right text-black">
                <ul class="wow fadeInUp" data-wow-delay=".1s">
                    <li><a href="<?php echo e(route('terms')); ?>">Terms & Conditions</a></li>
                    <li><a href="<?php echo e(route('privacy')); ?>">Privacy Policy</a></li>
                    <li><a href="#contact">Contact Us</a></li>
                </ul>
            </div>
        </div>
    </div>
    <div class="row">
        <!--Text-->
        <div class="col-lg-12 ">
            <p class="company-about fadeIn">© Sofia. All Rights Reserved.</a>
            </p>
        </div>
    </div>
</section>

<div class="footer-icon">
    <a href="https://wa.me/<?php echo e($site_setting->whatsapp); ?>" target="_blank">
        <img src="<?php echo e(asset('SOFIA/icons/whatsapp@2x-1.png')); ?>">
    </a>
</div>
<?php /**PATH E:\wamp64\www\java-game\resources\views/footer.blade.php ENDPATH**/ ?>