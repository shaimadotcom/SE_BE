
<!-- JavaScript -->
<script src="<?php echo e(asset('vendor/js/bundle.min.js')); ?>"></script>

<!-- Plugin Js -->
<script src="<?php echo e(asset('vendor/js/jquery.fancybox.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/js/owl.carousel.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/js/swiper.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/js/jquery.cubeportfolio.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/js/jquery.appear.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/js/parallaxie.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/js/wow.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/js/select2.min.js')); ?>"></script>
<!-- Slick JS File -->
<script src="<?php echo e(asset('vendor/js/slick.min.js')); ?>"></script>

<!-- REVOLUTION JS FILES -->
<script src="<?php echo e(asset('vendor/js/jquery.themepunch.tools.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/js/jquery.themepunch.revolution.min.js')); ?>"></script>
<!-- SLIDER REVOLUTION EXTENSIONS -->
<script src="<?php echo e(asset('vendor/js/extensions/revolution.extension.actions.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/js/extensions/revolution.extension.carousel.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/js/extensions/revolution.extension.kenburn.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/js/extensions/revolution.extension.layeranimation.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/js/extensions/revolution.extension.migration.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/js/extensions/revolution.extension.navigation.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/js/extensions/revolution.extension.parallax.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/js/extensions/revolution.extension.slideanims.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/js/extensions/revolution.extension.video.min.js')); ?>"></script>

<!-- Google Map Api -->



<!--contact form-->
<script src="<?php echo e(asset('vendor/js/contact_us.js')); ?>"></script>

<!-- custom script -->
<script src="<?php echo e(asset('consulting/js/script.js')); ?>"></script>
<?php /**PATH E:\wamp64\www\abdulcpa\resources\views/js.blade.php ENDPATH**/ ?>