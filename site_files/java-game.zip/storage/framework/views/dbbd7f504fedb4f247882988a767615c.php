<?php $__env->startPush('css'); ?>


<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

    <?php
    $slider = \App\Models\Product::where('status', 1)->where('show_in_banner', 1)->orderBy('id', 'desc')->skip(0)->take(3)->get();
    ?>
        <!-- Start banner -->
    <section class="banner-sec banner-image" id="banner">
        <div class="container">
            <div class="row">
                <div class="col-lg-4 d-flex align-items-center justify-content-center">
                    <?php $__currentLoopData = $slider; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="banner-area <?php echo e($key>0?'hidden':''); ?> animate__animated" id="banner-area-<?php echo e($key+1); ?>">
                            <?php if($s->banner_badge): ?>
                                <a href="#" class="badge badge-danger"
                                   style="background: <?php echo e($s->banner_badge_color); ?>;"><?php echo e($s->banner_badge); ?></a>
                            <?php endif; ?>
                            <h2 class="banner-heading">
                                <?php echo e($s->banner_title); ?>

                            </h2>
                            <h4 class="banner-des"><?php echo e($s->banner_description); ?></h4>
                            <a href="#about" class="btn primary-btn">Contact us</a>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="col-md-8 show-desktop">
                    <div class="row">
                        <?php $__currentLoopData = $slider; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                $image = json_decode($s->images);
                                ?>
                            <div class="col-md-4">
                                <div id="slider-<?php echo e($key+1); ?>" class="slider animate__animated <?php echo e($key==0?'active':''); ?>">
                                    <div class="line1"></div>
                                    <div class="line2">
                                        <div style="">
                                            <img class="vector" id="vector-<?php echo e($key+1); ?>"
                                                 src="<?php echo e($key==0?asset('SOFIA/Vector-white.png'):asset('SOFIA/Vector.png')); ?>"
                                                 width="80%">
                                        </div>
                                    </div>
                                    <div class="line3">
                                        <div class="slider-brand">
                                            <?php echo e($s->brand?$s->brand->title:''); ?>

                                        </div>
                                        <div class="slider-title">
                                            <?php echo e($s->title); ?>

                                        </div>
                                        <div class="slider-desc">
                                            <?php echo e(substr($s->description,0,80)); ?> <?php if(strlen($s->description)>80): ?> ... <?php endif; ?>
                                        </div>
                                        <div class="separator"></div>
                                        <div class="p-state <?php echo e($s->in_stock==1?'in':'out'); ?>">

                                        </div>
                                        <div class="line4">
                                            <div class="line5">
                                                <a class="get-quote">
                                                    Get Quote
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <img class="top-img"
                                         src="<?php echo e(Voyager::image($image[0])); ?>"/>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- End banner -->

    <section class="services">
        <div class="container">
            <div class="row">
                <?php $__currentLoopData = \App\Models\Service::get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-6 col-md-3 mt-5 p-2">
                        <div class="service-item">
                            <div class="img">
                                <div>
                                    <img src="<?php echo e(Voyager::image($s->logo)); ?>">
                                </div>
                            </div>
                            <div class="info">
                                <div class="div1">
                                    <?php echo e($s->title); ?>

                                </div>
                                <div class="div2">
                                    <?php echo $s->description; ?>

                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>


    <!-- Start feature -->
    <section id="about" class="feature-sec feature-image"
             style="background-image: url('<?php echo e(Voyager::image($content->about_image)); ?>')">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <div class="feature-area">
                        <div class="title">
                            About SOFIA
                        </div>
                        <div>
                            <?php echo $content->about_text; ?>

                        </div>
                        <a class="btn primary-btn" href="#contact">GET Quote</a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- End feature -->

    <section class="products" id="products">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="products-header"
                         style="background-image: url('<?php echo e(Voyager::image($content->products_banner)); ?>')">
                        <div class="header-text"><?php echo e($content->products_banner_text); ?></div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="tabs">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="tabs-header">Our Products</div>
                            </div>
                            <div class="col-md-6 text-right">
                                <?php $__currentLoopData = \App\Models\Category::get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <a onclick="showProducts(<?php echo e($c->id); ?>)"
                                       id="cat-<?php echo e($c->id); ?>"
                                       class="tabs-button <?php echo e($key==0?'active':''); ?>"><?php echo e($c->title); ?></a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row mt-5">
                <?php $__currentLoopData = \App\Models\Category::get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                        $products = \App\Models\Product::where('category_id', $c->id)->where('status', 1)->orderBy('id', 'desc')->skip(0)->take(12)->get();
                        ?>
                    <div class="col-md-12 pcs <?php echo e($key==0?'':'hidden'); ?>" id="pcs-<?php echo e($c->id); ?>">
                        <div class="row" id="products-<?php echo e($key); ?>">
                            <?php echo $__env->make('products',['products'=>$products,'skip'=>0], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                        <?php if(sizeof($products)>0): ?>
                            <div class="row">
                                <div class="col-md-12 text-center hidden" id="load-<?php echo e($key); ?>">
                                    <img src="<?php echo e(asset('loader.gif')); ?>" width="50">
                                </div>
                                <div class="col-md-12 text-center" id="load-more-<?php echo e($key); ?>">
                                    <a onclick="loadMore(<?php echo e($key); ?>,<?php echo e($c->id); ?>)"
                                       class="btn pointer primary-btn view-more">View
                                        More</a>
                                </div>
                            </div>
                        <?php else: ?>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="alert alert-warning text-center" style="font-size: 14px;">
                                        No Products Yet!
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>

    <section class="banner">
        <div class="banner-main" style="background-image:url('<?php echo e(Voyager::image($content->quote_banner)); ?>');">
            <div class="banner-content">
                <div class="banner-title">
                    <?php echo e($content->get_quote_title); ?>

                </div>
                <div class="banner-text">
                    <?php echo e($content->quote_banner_text); ?>

                </div>
                <div><a class="btn primary-btn get-quote" href="#contact">
                        Get Quote
                    </a></div>
            </div>
        </div>
    </section>

    <section class="partners">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="tabs-header mb-3">Our Brands</div>
                </div>
            </div>
            <div class="row">
                <?php $__currentLoopData = \App\Models\Level::where('show_home',1)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-6 col-md-2 partner text-center">
                        <img src="<?php echo e(Voyager::image($b->logo)); ?>" style="height: 35px;">
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>

    <section class="banner">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <div class="left-banner wow slideInLeft" data-wow-delay=".2s"
                         style="background-image: url('<?php echo e(Voyager::image($content->left_banner)); ?>')">
                        <div class="content">
                            <h4><?php echo e($content->left_banner_text); ?></h4>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="right-banner wow slideInRight" data-wow-delay=".2s"
                         style="background-image: url('<?php echo e(Voyager::image($content->right_banner)); ?>')">
                        <div class="content">
                            <span class="badge badge-danger">New</span>
                            <h4><?php echo e($content->right_banner_text); ?></h4>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Start contact -->
    <section class="contact-sec bg-contact" id="contact">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="get-touche">
                        Get in Touch
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-7">
                    <div class="get-touche-desc">
                        <?php echo $content->get_touch; ?>

                    </div>
                </div>
            </div>
            <div class="row contact-form-div">
                <div class="col-12 col-md-12 col-lg-7 wow slideInLeft" data-wow-delay=".1s">
                    <form class="row contact-form row-padding" action="<?php echo e(route('contact-us')); ?>" method="POST">
                        <div class="col-12 col-lg-10" id="result"></div>
                        <?php echo csrf_field(); ?>
                        <div class="col-12 col-lg-10 contact-inputs">
                            <h4 class="text-black font-weight-bold">Send us a message</h4>
                            <input type="text" name="name" placeholder="Name" class="form-control">
                            <input type="email" name="email" placeholder="Email" class="form-control">
                            <input type="text" name="phone" placeholder="Phone" class="form-control">
                            <textarea class="form-control" name="text" rows="6"
                                      placeholder="Enter your message"></textarea>
                            <button type="submit"
                                    class="btn primary-btn send">
                                Send
                            </button>
                        </div>
                    </form>
                </div>
                <div class="col-12 col-md-12 col-lg-5 wow slideInRight address-area" data-wow-delay=".1s">
                    <div class="contact-area">
                        <h6 class="contact-heading">Contact Us</h6>
                    </div>
                    <div class="contact-details">
                        <ul>
                            <li>
                                <i aria-hidden="true" class="las la-phone"></i>
                                <div>
                                    <span><?php echo e($site_setting->contact_phone1); ?></span>
                                    <br/>
                                    <span><?php echo e($site_setting->contact_phone2); ?></span>
                                </div>
                            </li>
                            <li><i aria-hidden="true" class="las la-envelope"></i>
                                <div>
                                    <span><?php echo e($site_setting->contact_email1); ?></span>
                                    <br/>
                                    <span><?php echo e($site_setting->contact_email2); ?></span>
                                </div>
                            </li>
                            <li><i aria-hidden="true" class="las la-map-marker"></i>
                                <span><?php echo e($site_setting->address); ?></span></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- End contact -->

<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>

    <script>
        function showProducts(cat) {
            $('.tabs-button').removeClass('active');
            $('#cat-' + cat).addClass('active');
            $('.pcs').addClass('hidden');
            $('#pcs-' + cat).removeClass('hidden');
        }

        var cats_ids = [];
        var cats_indexes = [];
        <?php $__currentLoopData = \App\Models\Category::get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            cats_ids['<?php echo e($key); ?>'] = <?php echo e($c->id); ?>;
        cats_indexes['<?php echo e($key); ?>'] = 12;
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        function loadMore(key, cat) {
            $('#load-' + key).removeClass('hidden');
            $.ajax({
                url: "<?php echo e(route('get-products')); ?>/" + cats_indexes[key] + "/" + cat
            }).done(function (data) {
                $('#load-' + key).addClass('hidden');
                if (parseInt(data) == -1) {
                    $('#load-more-' + key).addClass('hidden');
                } else {
                    $('#products-' + key).append(data);
                    cats_indexes[key] = cats_indexes[key] + 12;
                    runCarousel();
                }
            });
        }
    </script>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp64\www\mobile-store\resources\views/index.blade.php ENDPATH**/ ?>
