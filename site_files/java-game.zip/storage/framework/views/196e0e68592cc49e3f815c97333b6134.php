<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Meta Tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="<?php echo e($site_setting->description); ?>">
    <!-- keywords -->
    <meta name="keywords" content="<?php echo e($site_setting->keywords); ?>">
    <!-- Page Title -->
    <title><?php echo e($site_setting->title); ?></title>

    <?php echo $__env->yieldPushContent('meta'); ?>

    <?php echo $__env->make('css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<body data-spy="scroll" data-target=".navbar-nav" data-offset="90">

<!-- Loader -->
<div class="loader" id="loader-fade">
    <div class="loader-container">
        <ul class="loader-box">
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
        </ul>
    </div>
</div>
<!-- Loader ends -->

<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->yieldContent('content'); ?>

<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldPushContent('js'); ?>
</body>
</html>
<?php /**PATH E:\wamp64\www\abdulcpa\resources\views/app.blade.php ENDPATH**/ ?>