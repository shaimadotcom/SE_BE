<!-- CSS Files
    ================================================== -->
<link href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css" id="bootstrap" />
<link href="<?php echo e(asset('assets/css/plugins.css')); ?>" rel="stylesheet" type="text/css">
<link href="<?php echo e(asset('assets/css/style.css')); ?>" rel="stylesheet" type="text/css">
<link href="<?php echo e(asset('assets/css/color.css')); ?>" rel="stylesheet" type="text/css">

<!-- custom background -->
<link rel="stylesheet" href="<?php echo e(asset('assets/css/bg.css')); ?>" type="text/css">

<!-- color scheme -->
<link rel="stylesheet" href="<?php echo e(asset('assets/css/colors/yellow-2.css')); ?>" type="text/css" id="colors">

<!-- RS5.0 Stylesheet -->
<link rel="stylesheet" href="<?php echo e(asset('assets/revolution/css/settings.css')); ?>" type="text/css">
<link rel="stylesheet" href="<?php echo e(asset('assets/revolution/css/layers.css')); ?>" type="text/css">
<link rel="stylesheet" href="<?php echo e(asset('assets/revolution/css/navigation.css')); ?>" type="text/css">
<link rel="stylesheet" href="<?php echo e(asset('assets/css/rev-settings.css')); ?>" type="text/css">
<link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css" type="text/css">

<!-- custom font -->
<link rel="stylesheet" href="<?php echo e(asset('assets/css/font-style-3.css')); ?>" type="text/css">
<link rel="stylesheet" href="<?php echo e(asset('assets-new/styles-min-mr.css')); ?>" type="text/css">
<link rel="stylesheet" href="<?php echo e(asset('assets/css/custom.css')); ?>" type="text/css">
<?php /**PATH E:\wamp64\www\systemahr\resources\views/css.blade.php ENDPATH**/ ?>