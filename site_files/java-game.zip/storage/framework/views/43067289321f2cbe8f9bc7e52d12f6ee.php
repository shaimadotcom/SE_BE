<?php $__env->startPush('css'); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

    <!-- subheader -->
    <section id="subheader" data-speed="8"

             style="background: url('<?php echo e(asset('assets-new/files/about-us/17.png')); ?>');background-position: center;}"
    >
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h1>Contact</h1>
                    <ul class="crumb">
                        <li><a href="<?php echo e(route('index')); ?>">Home</a></li>
                        <li class="sep">/</li>
                        <li>Contact</li>
                    </ul>
                </div>
            </div>
        </div>
    </section>
    <!-- subheader close -->

    <!-- content begin -->
    <div id="content" class="no-top mt-5">












        <div class="container">
            <div class="row">

                <div class="col-md-8">
                    <form name="contactForm" id='contact_form' action="<?php echo e(route('contact-us')); ?>" method="post">
                        <div class="row">
                            <div class="col-md-12 mb10">
                                <h3>Send Us Message</h3>
                            </div>
                            <div class="col-md-6">
                                <div id='name_error' class='error'>Please enter your name.</div>
                                <div>
                                    <input type='text' name='Name' id='name' class="form-control" placeholder="Your Name" required="">
                                </div>
<?php echo csrf_field(); ?>
                                <div id='email_error' class='error'>Please enter your valid E-mail ID.</div>
                                <div>
                                    <input type='email' name='Email' id='email' class="form-control" placeholder="Your Email" required="">
                                </div>

                                <div id='phone_error' class='error'>Please enter your phone number.</div>
                                <div>
                                    <input type='text' name='phone' id='phone' class="form-control" placeholder="Your Phone" required="">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div id='message_error' class='error'>Please enter your message.</div>
                                <div>
                                    <textarea name='text' id='message' class="form-control" placeholder="Your Message" required=""></textarea>
                                </div>
                            </div>

                            <div class="col-md-12">
                                <div class="g-recaptcha" data-sitekey="6LdW03QgAAAAAJko8aINFd1eJUdHlpvT4vNKakj6"></div>
                                <p id='submit' class="mt20">
                                    <input type='submit' id='send_message' value='Submit Form' class="btn btn-line">
                                </p>
                            </div>
                        </div>
                    </form>

                </div>

                <div id="sidebar" class="col-md-4">

                    <div class="widget widget_text">
                        <h3>Contact Info</h3>
                        <address>
                            <span><strong><i class="fa fa-phone con-f"></i></strong> <a href="tel:+971 50 613 6796">+971 50 613 6796</a></span>
                            <span><strong><i class="fa fa-phone con-f"></i></strong> <a href="tel:+966 59 810 6796">+966 59 810 6796</a></span>
                            <span><strong><i class="fa fa-envelope con-f"></i></strong><a href="mailto:info@systemahr.com">info@systemahr.com</a></span>
                            <span><strong><i class="fa fa-envelope con-f"></i></strong><a href="mailto:alaa@systemahr.com">alaa@systemahr.com</a></span>
                            <span><strong><i class="fa fa-internet-explorer con-f"></i></strong><a href="<?php echo e(url('')); ?>"><?php echo e(url('')); ?></a></span>
                        </address>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<script>
    var frm = $('#contact_form');

    frm.submit(function (e) {
        $('#send_message').prop("disabled", "disabled");
        e.preventDefault();
        e.stopPropagation();

        $.ajax({
            type: frm.attr('method'),
            url: frm.attr('action'),
            async: false,
            data: frm.serialize(),
            success: function (data) {
                if (data && data.status == 1) {
                    $('#user_balance').html(data.user_balance);
                    frm.trigger('reset');
                    toastr.success(data.msg);
                } else {
                    toastr.error(data.msg);
                }
                $('#send_message').prop("disabled", false);
            },
            error: function (data) {
                $('#send_message').prop("disabled", false);
                toastr.error(data.msg);
            },
        });

    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp64\www\systemahr\resources\views/contact-us.blade.php ENDPATH**/ ?>