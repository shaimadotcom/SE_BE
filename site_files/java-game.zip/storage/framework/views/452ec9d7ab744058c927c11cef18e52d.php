<html>
<body>
<table style="width: 100%;text-align: left;border-collapse: collapse;" border="1">
    <tr>
        <td>Name</td>
        <td><?php echo e($name); ?></td>
    </tr>
    <tr>
        <td>Email</td>
        <td><?php echo e($email); ?></td>
    </tr>
    <tr>
        <td>Phone</td>
        <td><?php echo e($phone); ?></td>
    </tr>
    <tr>
        <td>Message:</td>
        <td><?php echo e($msg); ?></td>
    </tr>
</table>
</body>
</html>
<?php /**PATH E:\wamp64\www\mobile-store\resources\views/emails/contact-email.blade.php ENDPATH**/ ?>