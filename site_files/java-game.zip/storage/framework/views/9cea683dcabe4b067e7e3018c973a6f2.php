<?php $__env->startPush('css'); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startSection('under-header'); ?>
    <!-- subheader -->
    <section id="subheader" data-speed="8"
             style="background: url('<?php echo e(asset('assets-new/files/about-us/17.png')); ?>');background-position: center;}"
    >
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h1>About Us</h1>
                    <ul class="crumb">
                        <li><a href="<?php echo e(route('index')); ?>">Home</a></li>
                        <li class="sep">/</li>
                        <li>About Us</li>
                    </ul>
                </div>
            </div>
        </div>
    </section>
    <!-- subheader close -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <section id="section-about-us-2 " class="no-padding">
        <div class="row">
            <div class="col-md-6 mt-5" data-delay="0">
                <video autoplay muted class="about-video" style="width: 100%;">
                    <source src="<?php echo e(asset('assets-new/files/website-video-2.mp4')); ?>" type="video/mp4">
                </video>
            </div>
            <div class="col-md-5 text-justify" data-animation="fadeInRight" data-delay="200">
                <div class="inner-padding">
                    <h2>ABOUT US</h2>

                    <div style="text-align: justify;">
                        <p>
                            At Systema HR, we embark on a transformative journey to reshape the Learning and Development
                            (L&D) terrain, steering both individuals and organizations towards their pinnacle of
                            excellence. Our steadfast dedication to fostering success through continuous learning is not
                            just a commitment—it's a philosophy ingrained in our extensive expertise and seasoned
                            experience. As architects of evolution in the L&D realm, we craft a narrative where every
                            learning opportunity becomes a stepping stone toward unparalleled achievement.
                        </p>
                        <p>
                            Adapting alongside the ever-changing global landscape, we consistently evolve our methods to
                            offer cutting-edge solutions. Our approach seamlessly blends innovation with proven
                            strategies, empowering clients to thrive in today's dynamic world. As a leading in the
                            industry, the track record of our team of impactful transformations and sustained growth
                            underscores our commitment to excellence. Our team of seasoned professionals continues to
                            pave the way for success, providing tailor-made solutions that cater to the unique needs of
                            our clients. The foundation of our legacy is built on trust, integrity, and a shared passion
                            for continual growth.
                        </p>
                    </div>

                </div>
                <div class="clearfix"></div>
            </div>
        </div>

    </section>


    <section>
        <div class="container">
            <div class="row">
                <div class="col-md-6 offset-md-3 text-center wow fadeInUp">
                    <h1>Our Partners</h1>
                </div>
                <div class="spacer-single"></div>

                <div class="col-md-12 wow fadeInRight" data-wow-delay="0s">
                    <div class="owl-carousel reviews-carousel">
                        <?php for($i=1;$i<=14;$i++): ?>
                            <div class="text-center">
                                <img src="<?php echo e(asset('assets-new/files/clients logos/'.$i.'.png')); ?>"
                                     style="max-width: 125px !important;">
                            </div>
                        <?php endfor; ?>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <!-- section begin -->
    <section id="section-testimonial-architecture"
             data-bgimage="url(<?php echo e(asset('assets-new/files/reviews/1.png')); ?>) fixed">
        <div class="container">
            <div class="row">

                <div class="col-md-8 offset-md-2">

                    <div id="testimonial-carousel-single" class="owl-carousel owl-theme wow fadeInUp">
                        <blockquote class="testimonial-big">
                            <span class="title">Inspirational Learning Journeys</span>
                            "Systema HR has transformed our approach to Learning and Development, turning each opportunity into a stepping stone for unparalleled achievement. Their commitment to continuous learning is both inspiring and effective. Their adaptability in a dynamic global landscape, blended with innovative strategies, has empowered our organization to thrive."

                            
                        </blockquote>

                        <blockquote class="testimonial-big">
                            <span class="title">Leaders in Evolutionary Solutions</span>
                            "As a leading figure in the industry, Systema HR's track record of impactful transformations and sustained growth speaks volumes. Their team of seasoned professionals not only understands our unique needs but also crafts tailor-made solutions that pave the way for success. Trust, integrity, and a shared passion for continual growth define their legacy."
                            
                        </blockquote>

                        <blockquote class="testimonial-big">
                            <span class="title">Extraordinary Impact, Enduring Excellence</span>
                            "Our experience with Systema HR has been nothing short of extraordinary. Their commitment to reshaping the Learning and Development terrain is evident in the enduring excellence they bring to every project. Systema HR is not just a provider; they are architects of positive change, consistently evolving their methods to offer cutting-edge solutions that fuel success in today's dynamic world."
                            
                        </blockquote>
                    </div>

                </div>

            </div>

        </div>
    </section>
    <!-- section close -->

    <!-- section begin -->
    <section id="view-all-projects" class="call-to-action bg-color dark text-center" data-speed="5"
             data-type="background" aria-label="view-all-projects">
        <a href="<?php echo e(route('contact-us')); ?>" class="btn btn-line black btn-big">Talk With Us</a>
    </section>
    <!-- logo carousel section close -->

<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script>
        $(document).ready(function () {
            $(".reviews-carousel").owlCarousel({
                center: false,
                items: 6,
                loop: true,
                dots: true,
                autoplay: true,
                autoplaySpeed: 1000,
                margin: 0,
                responsive: {
                    1000: {
                        items: 6
                    },
                    600: {
                        items: 4
                    },
                    0: {
                        items: 2
                    }
                }
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp64\www\systemahr\resources\views/about-us.blade.php ENDPATH**/ ?>