












<?php /**PATH E:\wamp64\www\systemahr\vendor\tcg\voyager\src/../resources/views/partials/app-footer.blade.php ENDPATH**/ ?>