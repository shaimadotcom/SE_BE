
<!-- footer begin -->
<footer class="style-2">
    <div class="container">
        <div class="row align-items-middle">
            <div class="col-md-3">
                <img src="<?php echo e(asset('assets/images-architecture/logo.png')); ?>" class="logo-small" alt=""><br>
            </div>

            <div class="col-md-6 text-center">
                &copy; Copyright <?php echo e(date('Y')); ?> - Developed by <a target="_blank" href="https://clenicode.ae/"><span class="id-color">Clenicode.ae</span></a>
            </div>

            <div class="col-md-3 text-right">
                <div class="social-icons">
                    <a href="#"><i class="fa fa-facebook fa-lg"></i></a>
                    <a href="#"><i class="fa fa-twitter fa-lg"></i></a>
                    <a href="#"><i class="fa fa-envelope fa-lg"></i></a>
                    <a href="#"><i class="fa fa-phone fa-lg"></i></a>




                </div>
            </div>
        </div>
    </div>


    <a href="#" id="back-to-top"></a>
</footer>
<!-- footer close -->
<?php /**PATH E:\wamp64\www\systemahr\resources\views/footer.blade.php ENDPATH**/ ?>