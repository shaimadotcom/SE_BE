<?php $__env->startPush('css'); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startSection('under-header'); ?>

    <!-- subheader -->
    <section id="subheader" data-speed="8"
             
             style="background: url('<?php echo e(asset('assets-new/files/solutions/'.$data->id.'/1.webp')); ?>');background-position: center;}">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h1><?php echo e($data->title); ?></h1>
                    <ul class="crumb">
                        <li><a href="<?php echo e(route('index')); ?>">Home</a></li>
                        <li class="sep">/</li>
                        <li>Solutions</li>
                    </ul>
                </div>
            </div>
        </div>
    </section>
    <!-- subheader close -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="row mb-5">


            <div class="col-md-8 m-auto mt-4">



                <div class="blog-read">
                    <div class="post-content">
                        <?php if($data->id==3): ?>
                            <video autoplay="" playsinline="" loop="" muted="" style="display: block;max-width: 100px;"
                                   src="<?php echo e(asset('assets-new/files/industry field mission video-2.mp4')); ?>"></video>
                        <?php else: ?>
                            <img style="width: 100%;border-radius: 5px;" src="<?php echo e(asset('assets-new/files/solutions/'.$data->id.'/2.webp')); ?>" alt=""/>
                        <?php endif; ?>
                    </div>

                </div>


            </div>


            <div class="col-md-8 mt-5 m-auto">



                <div class="blog-read">
                    <div class="post-content">
                        <div class="date-box">
                            <div class="day"><?php echo e(date('d')); ?></div>
                            <div class="month"
                                 style="letter-spacing: 1px;font-size: 11px;"><?php echo e(strtoupper(date('F'))); ?></div>
                        </div>

                        <div class="post-text">
                            <h3><a href="#"><?php echo e($data->title); ?></a></h3>
                            <div>
                                <?php echo $data->big_text; ?>

                            </div>
                        </div>
                    </div>


                </div>


            </div>

        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp64\www\systemahr\resources\views/solutions.blade.php ENDPATH**/ ?>