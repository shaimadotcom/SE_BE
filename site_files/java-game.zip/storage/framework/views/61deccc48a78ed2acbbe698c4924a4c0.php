<?php $__env->startSection('content'); ?>
    <!-- Main Section start -->
    <section id="home" class="p-0 no-transition h-100vh">
        <h2 class="d-none">heading</h2>
        <!--Main Slider-->
        <div id="revo_thumbs_wrapper" class="rev_slider_wrapper fullwidthbanner-container">
            <div id="secondary-banner" class="rev_slider fullwidthabanner" style="display:none;" data-version="5.4.1">
                <ul>
                    <!-- SLIDE 1 -->
                    <li data-index="rs-01" data-transition="fade" data-slotamount="default"
                        data-easein="Power3.easeInOut"
                        data-easeout="Power3.easeInOut" data-masterspeed="2000" data-fsmasterspeed="1500"
                        data-param1="">
                        <!-- MAIN IMAGE -->
                        <img src="consulting/img/banner1.jpg" alt="" data-bgposition="center center" data-bgfit="cover"
                             data-bgrepeat="no-repeat" class="rev-slidebg" data-bgparallax="0" data-no-retina>
                        <!-- LAYER NR. 1 -->
                        <div class="tp-caption tp-resizeme rs-parallaxlevel-8 bg-blue blue-box"
                             data-x="['center','center','center','center']" data-hoffset="['80','80','0','0']"
                             data-y="['middle','middle','middle','middle']" data-voffset="['0','0','0','10']"
                             data-whitespace="nowrap"
                             data-width="['615px','615px','490px','292px']"
                             data-height="['500px','500px','425px','261px']"
                             data-responsive_offset="on"

                             data-frames='[{"delay":319.921875,"speed":500,"frame":"0","from":"z:0;rX:0;rY:0;rZ:0;sX:0.9;sY:0.9;skX:0;skY:0;opacity:0;","to":"o:1;","ease":"Power2.easeOut"},{"delay":"wait","speed":300,"frame":"999","to":"opacity:0;","ease":"Power3.easeInOut"}]'
                             data-textAlign="['inherit','inherit','inherit','inherit']"
                             data-paddingtop="[0,0,0,0]"
                             data-paddingright="[0,0,0,0]"
                             data-paddingbottom="[0,0,0,0]"
                             data-paddingleft="[0,0,0,0]"

                             style="z-index: 0;">

                        </div>
                        <!-- LAYER NR. 2 -->
                        <div class="tp-caption tp-resizeme"
                             data-x="['left','left','center','center']" data-hoffset="['70','70','0','0']"
                             data-y="['middle','middle','middle','middle']" data-voffset="['-105','-105','-105','-90']"
                             data-fontsize="['55','55','55','35']"
                             data-whitespace="nowrap" data-responsive_offset="on"
                             data-width="['none','none','none','none']" data-type="text"
                             data-textalign="['left','left','center','center']"
                             data-frames='[{"delay":0,"speed":2000,"frame":"0","from":"z:0;rX:0;rY:0;rZ:0;sX:0.9;sY:0.9;skX:0;skY:0;opacity:0;","to":"o:1;","ease":"Power3.easeInOut"},{"delay":"wait","speed":300,"frame":"999","to":"auto:auto;","ease":"Power3.easeInOut"}]'
                             data-start="1000" data-splitin="none" data-splitout="none"
                             style="z-index:1; font-weight: 300; color: #ffffff;font-family: 'Raleway', sans-serif;text-transform:capitalize">
                            We're not just tax preparers

                        </div>
                        <div class="tp-caption tp-resizeme bg-green"
                             data-x="['left','left','center','center']" data-hoffset="['75','75','5000','5000']"
                             data-y="['middle','middle','middle','middle']" data-voffset="['-20','-20','-20','20']"
                             data-width="['45px','45px','45px','45px']"
                             data-height="['4px','4px','4px','4px']"
                             data-whitespace="nowrap"

                             data-type="image"
                             data-responsive_offset="on"

                             data-frames='[{"delay":319.921875,"speed":1500,"frame":"0","from":"z:0;rX:0;rY:0;rZ:0;sX:0.9;sY:0.9;skX:0;skY:0;opacity:0;","to":"o:1;","ease":"Power2.easeOut"},{"delay":"wait","speed":300,"frame":"999","to":"opacity:0;","ease":"Power3.easeInOut"}]'
                             data-textAlign="['inherit','inherit','inherit','inherit']"
                             data-paddingtop="[0,0,0,0]"
                             data-paddingright="[0,0,0,0]"
                             data-paddingbottom="[0,0,0,0]"
                             data-paddingleft="[0,0,0,0]"

                             style="z-index: 0;">
                            <div class="rs-looped rs-slideloop d-none d-md-block" data-speed="5" data-xs="-10"
                                 data-xe="10"
                                 data-ys="0" data-ye="0" data-origin="50% 50%"></div>

                        </div>
                        <!-- LAYER NR. 3 -->
                        <div class="tp-caption tp-resizeme"
                             data-x="['left','left','center','center']" data-hoffset="['150','150','0','0']"
                             data-y="['middle','middle','middle','middle']" data-voffset="['-30','-30','-30','-15']"
                             data-fontsize="['55','55','55','35']"
                             data-whitespace="nowrap" data-responsive_offset="on"
                             data-width="['none','none','none','none']" data-type="text"
                             data-textalign="['left','left','center','center']"
                             data-frames='[{"delay":1000,"speed":1500,"frame":"0","from":"x:-50px;opacity:0;","to":"o:1;","ease":"Power3.easeInOut"},{"delay":"wait","speed":300,"frame":"999","to":"auto:auto;","ease":"Power3.easeInOut"}]'
                             data-start="1500" data-splitin="none" data-splitout="none"
                             style="z-index:1; font-weight: 300; line-height: 60px; color: #ffffff;font-family: 'Raleway', sans-serif;text-transform:capitalize">
                            we're strategic tax planners

                            <div class="rs-looped rs-slideloop d-none d-md-block" data-speed="5" data-xs="-10"
                                 data-xe="10"
                                 data-ys="0" data-ye="0" data-origin="50% 50%"></div>
                        </div>
                        <!-- LAYER NR. 4 -->
                        <div class="tp-caption tp-resizeme"
                             data-x="['left','left','center','center']" data-hoffset="['70','70','0','0']"
                             data-y="['middle','middle','middle','middle']" data-voffset="['40','40','40','50']"
                             data-fontsize="['55','55','55','35']"
                             data-whitespace="nowrap" data-responsive_offset="on"
                             data-width="['none','none','none','none']" data-type="text"
                             data-textalign="['left','left','center','center']"
                             data-frames='[{"delay":1500,"speed":1500,"frame":"0","from":"x:[100%];opacity:1;","mask":"x:[-100%];y:0;s:inherit;e:inherit;","to":"o:1;","ease":"Power4.easeInOut"},{"delay":"wait","speed":300,"frame":"999","to":"x:[100%];opacity:1;","mask":"x:[-100%];y:0;s:inherit;e:inherit;","ease":"Power4.easeInOut"}]'
                             data-start="2000" data-splitin="none" data-splitout="none"
                             style="z-index:1; font-weight: 500; line-height: 60px; color: #ffffff;font-family: 'Raleway', sans-serif;text-transform:capitalize">
                            At Abdul CPA
                        </div>

                    </li>
                    <!-- SLIDE 3 -->
                    <li data-index="rs-03" data-transition="fade" data-slotamount="default"
                        data-easein="Power3.easeInOut"
                        data-easeout="Power3.easeInOut" data-masterspeed="2000" data-fsmasterspeed="1500"
                        data-param1="">
                        <!-- MAIN IMAGE -->
                        <img src="consulting/img/banner3.jpg" alt="" data-bgposition="center center" data-bgfit="cover"
                             data-bgrepeat="no-repeat" class="rev-slidebg" data-bgparallax="0" data-no-retina>
                        <div class="bg-overlay bg-black opacity-7"></div>
                        <!-- LAYER NR. 1 -->
                        <div class="tp-caption tp-resizeme rs-parallaxlevel-8 bg-green blue-box"
                             data-x="['center','center','center','center']" data-hoffset="['-160','-160','0','0']"
                             data-y="['middle','middle','middle','middle']" data-voffset="['0','0','0','10']"
                             data-whitespace="nowrap"
                             data-width="['615px','615px','490px','292px']"
                             data-height="['500px','500px','425px','261px']"
                             data-responsive_offset="on"

                             data-frames='[{"delay":319.921875,"speed":500,"frame":"0","from":"z:0;rX:0;rY:0;rZ:0;sX:0.9;sY:0.9;skX:0;skY:0;opacity:0;","to":"o:1;","ease":"Power2.easeOut"},{"delay":"wait","speed":300,"frame":"999","to":"opacity:0;","ease":"Power3.easeInOut"}]'
                             data-textAlign="['inherit','inherit','inherit','inherit']"
                             data-paddingtop="[0,0,0,0]"
                             data-paddingright="[0,0,0,0]"
                             data-paddingbottom="[0,0,0,0]"
                             data-paddingleft="[0,0,0,0]"

                             style="z-index: 0;">

                        </div>
                        <!-- LAYER NR. 2 -->
                        <div class="tp-caption tp-resizeme"
                             data-x="['right','right','center','center']" data-hoffset="['70','70','0','0']"
                             data-y="['middle','middle','middle','middle']" data-voffset="['-105','-105','-105','-90']"
                             data-fontsize="['55','55','55','35']"
                             data-whitespace="nowrap" data-responsive_offset="on"
                             data-width="['none','none','none','none']" data-type="text"
                             data-textalign="['right','right','center','center']"
                             data-frames='[{"delay":0,"speed":2000,"frame":"0","from":"z:0;rX:0;rY:0;rZ:0;sX:0.9;sY:0.9;skX:0;skY:0;opacity:0;","to":"o:1;","ease":"Power3.easeInOut"},{"delay":"wait","speed":300,"frame":"999","to":"auto:auto;","ease":"Power3.easeInOut"}]'
                             data-start="1000" data-splitin="none" data-splitout="none"
                             style="z-index:1; font-weight: 300; color: #ffffff;font-family: 'Raleway', sans-serif;text-transform:capitalize">
                            Accurate tax findings

                        </div>
                        <div class="tp-caption tp-resizeme bg-blue"
                             data-x="['right','right','center','center']" data-hoffset="['300','300','5000','5000']"
                             data-y="['middle','middle','middle','middle']" data-voffset="['-20','-20','-20','20']"
                             data-width="['45px','45px','45px','45px']"
                             data-height="['4px','4px','4px','4px']"
                             data-whitespace="nowrap"

                             data-type="image"
                             data-responsive_offset="on"

                             data-frames='[{"delay":319.921875,"speed":1500,"frame":"0","from":"z:0;rX:0;rY:0;rZ:0;sX:0.9;sY:0.9;skX:0;skY:0;opacity:0;","to":"o:1;","ease":"Power2.easeOut"},{"delay":"wait","speed":300,"frame":"999","to":"opacity:0;","ease":"Power3.easeInOut"}]'
                             data-textAlign="['inherit','inherit','inherit','inherit']"
                             data-paddingtop="[0,0,0,0]"
                             data-paddingright="[0,0,0,0]"
                             data-paddingbottom="[0,0,0,0]"
                             data-paddingleft="[0,0,0,0]"

                             style="z-index: 0;">
                            <div class="rs-looped rs-slideloop d-none d-md-block" data-speed="5" data-xs="-10"
                                 data-xe="10"
                                 data-ys="0" data-ye="0" data-origin="50% 50%"></div>

                        </div>
                        <!-- LAYER NR. 3 -->
                        <div class="tp-caption tp-resizeme"
                             data-x="['right','right','center','center']" data-hoffset="['75','75','0','0']"
                             data-y="['middle','middle','middle','middle']" data-voffset="['-30','-30','-30','-15']"
                             data-fontsize="['55','55','55','35']"
                             data-whitespace="nowrap" data-responsive_offset="on"
                             data-width="['none','none','none','none']" data-type="text"
                             data-textalign="['right','right','center','center']"
                             data-frames='[{"delay":1000,"speed":1500,"frame":"0","from":"x:50px;opacity:0;","to":"o:1;","ease":"Power3.easeInOut"},{"delay":"wait","speed":300,"frame":"999","to":"auto:auto;","ease":"Power3.easeInOut"}]'
                             data-start="1500" data-splitin="none" data-splitout="none"
                             style="z-index:1; font-weight: 300; line-height: 60px; color: #ffffff;font-family: 'Raleway', sans-serif;text-transform:capitalize">
                            Fast return credit

                            <div class="rs-looped rs-slideloop d-none d-md-block" data-speed="5" data-xs="-10"
                                 data-xe="10"
                                 data-ys="0" data-ye="0" data-origin="50% 50%"></div>
                        </div>
                        <!-- LAYER NR. 4 -->
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        <!-- LAYER NR. 5 -->
                        <div class="tp-caption tp-resizeme"
                             data-x="['right','right','center','center']" data-hoffset="['60','60','0','0']"
                             data-y="['middle','middle','middle','middle']" data-voffset="['130','130','130','120']"
                             data-responsive_offset="['on','on','on','on']"
                             data-width="['320','320','320','320']"
                             data-textalign="['center','center','center','center']"
                             data-transform_idle="o:1;"
                             data-transform_in="y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;s:2000;e:Power4.easeInOut;"
                             data-transform_out="s:20;e:Power4.easeInOut;s:20;e:Power4.easeInOut;"
                             data-start="1200" data-splitin="none" data-splitout="none"
                             style="z-index:99; min-width: 960px; max-width: 960px">
                            <a href="#contact-form-data" class="scroll btn-setting btn-scale btn-white color-black">
                                Contact Us</a>
                            
                            
                        </div>
                    </li>
                    <!-- SLIDE 4 -->
                    <li data-index="rs-04" data-transition="fade" data-slotamount="default"
                        data-easein="Power3.easeInOut"
                        data-easeout="Power3.easeInOut" data-masterspeed="2000" data-fsmasterspeed="1500"
                        data-param1="">
                        <!-- MAIN IMAGE -->
                        <img src="consulting/img/banner2.jpg" alt="" data-bgposition="center center" data-bgfit="cover"
                             data-bgrepeat="no-repeat" class="rev-slidebg" data-bgparallax="0" data-no-retina>
                        <div class="bg-overlay bg-black opacity-7"></div>
                        <!-- LAYER NR. 2 -->
                        <div class="tp-caption tp-resizeme"
                             data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']"
                             data-y="['middle','middle','middle','middle']" data-voffset="['-135','-135','-135','-120']"
                             data-fontsize="['55','55','55','35']"
                             data-whitespace="nowrap" data-responsive_offset="on"
                             data-width="['none','none','none','none']" data-type="text"
                             data-textalign="['center','center','center','center']"
                             data-frames='[{"delay":0,"speed":2000,"frame":"0","from":"z:0;rX:0;rY:0;rZ:0;sX:0.9;sY:0.9;skX:0;skY:0;opacity:0;","to":"o:1;","ease":"Power3.easeInOut"},{"delay":"wait","speed":300,"frame":"999","to":"auto:auto;","ease":"Power3.easeInOut"}]'
                             data-start="1000" data-splitin="none" data-splitout="none"
                             style="z-index:1; font-weight: 300; color: #ffffff;font-family: 'Raleway', sans-serif;text-transform:capitalize">
                            Tax filing services
                        </div>
                        <!-- LAYER NR. 3 -->
                        <div class="tp-caption tp-resizeme"
                             data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']"
                             data-y="['middle','middle','middle','middle']" data-voffset="['-70','-70','-70','-55']"
                             data-fontsize="['55','55','55','35']"
                             data-whitespace="nowrap" data-responsive_offset="on"
                             data-width="['none','none','none','none']" data-type="text"
                             data-textalign="['center','center','center','center']"
                             data-frames='[{"delay":1000,"speed":1500,"frame":"0","from":"x:50px;opacity:0;","to":"o:1;","ease":"Power3.easeInOut"},{"delay":"wait","speed":300,"frame":"999","to":"auto:auto;","ease":"Power3.easeInOut"}]'
                             data-start="1500" data-splitin="none" data-splitout="none"
                             style="z-index:1; font-weight: 500; line-height: 60px; color: #ffffff;font-family: 'Raleway', sans-serif;text-transform:capitalize">
                            for small businesses
                        </div>
                        <!-- LAYER NR. 4 -->
                        <div class="tp-caption tp-resizeme"
                             data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']"
                             data-y="['middle','middle','middle','middle']" data-voffset="['5','5','5','15']"
                             data-fontsize="['55','55','55','35']"
                             data-whitespace="nowrap" data-responsive_offset="on"
                             data-width="['none','none','none','none']" data-type="text"
                             data-textalign="['center','center','center','center']"
                             data-frames='[{"delay":1500,"speed":1500,"frame":"0","from":"x:[100%];opacity:1;","mask":"x:[-100%];y:0;s:inherit;e:inherit;","to":"o:1;","ease":"Power4.easeInOut"},{"delay":"wait","speed":300,"frame":"999","to":"x:[100%];opacity:1;","mask":"x:[-100%];y:0;s:inherit;e:inherit;","ease":"Power4.easeInOut"}]'
                             data-start="2000" data-splitin="none" data-splitout="none"
                             style="z-index:1; font-weight: 300; line-height: 60px; color: #ffffff;font-family: 'Raleway', sans-serif;text-transform:capitalize">
                            at a competitive rate.
                        </div>
                        <!-- LAYER NR. 5 -->
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        <!-- LAYER NR. 6 -->
                        <div class="tp-caption tp-resizeme"
                             data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']"
                             data-y="['middle','middle','middle','middle']" data-voffset="['145','145','145','145']"
                             data-width="['180','180','180','180']"
                             data-frames='[{"delay":600,"speed":2000,"frame":"0","from":"sX:1;sY:1;opacity:0;fb:40px;","to":"o:1;fb:0;","ease":"Power4.easeInOut"},{"delay":"wait","speed":300,"frame":"999","to":"opacity:0;fb:0;","ease":"Power3.easeInOut"}]'
                             data-textAlign="['center','center','center','center']"
                             style="z-index:99; max-width: 960px">
                            <a href="#aboutus" class="scroll btn-setting btn-scale btn-green text-white">Read more</a>
                        </div>

                    </li>
                </ul>
            </div>
        </div>
        <!--Main Slider ends -->
    </section>
    <!-- Main Section end -->

    <!-- About start -->
    <section class="bg-light-gray3">
        <div class="container">
            <div class="row" id="aboutus">
                <div class="container">
                    <div
                        class="main-title style-two d-flex justify-content-md-around align-items-center flex-column flex-md-row text-center text-md-left wow fadeIn"
                        data-wow-delay="300ms">
                        <div class="mb-4 mb-md-0 abt-title">
                            <h5 class="text-left">QUALITY ACCOUNTING SERVICES</h5>
                        </div>
                        <div class="ml-md-4 pl-md-2">
                            <p class="mb-4">
                                We got an extensive background dealing with taxation and accounting demands for a wide
                                range of clients. Having worked with small startups, mid-size corporations, and
                                individuals, we're up for any challenge that comes our way. Whatever financial advice
                                you need, please contact us to see how we can get you started today.
                            </p>
                        </div>
                    </div>
                </div>
                <div class="container">
                    <div
                        class="main-title style-two d-flex justify-content-md-around align-items-center flex-column flex-md-row text-center text-md-left wow fadeIn"
                        data-wow-delay="300ms">
                        <div class="mb-4 mb-md-0 abt-title">
                            <h5 class="text-left">TAX PREPARATION</h5>
                        </div>
                        <div class="ml-md-4 pl-md-2">
                            <p class="mb-4">
                                Abdul CPA cares about your personal and business interests. With tailor-made accounting
                                services at your disposal, we’ll make sure your paying not a cent more in taxes than you
                                owe. We specialize in taking care of your accounting so you can concentrate on the
                                things that matter most. Contact us in order to hire our certified services immediately.
                            </p>
                        </div>
                    </div>
                </div>
                <div class="container">
                    <div
                        class="main-title style-two d-flex justify-content-md-around align-items-center flex-column flex-md-row text-center text-md-left wow fadeIn"
                        data-wow-delay="300ms">
                        <div class="mb-4 mb-md-0 abt-title">
                            <h5 class="text-left">BOOKKEEPING SERVICES</h5>
                        </div>
                        <div class="ml-md-4 pl-md-2">
                            <p class="mb-4">
                                Tired of trying to keep track of all your bookkeeping in an organized manner? With
                                AbdulCPA, you can take the burden of handling finances off your shoulders! We’ve
                                provided clients across the nation with extensive accounting services and we're
                                available around the clock for
                            </p>

                            <ul class="ol-list  pl-md-3">
                                <li>Automate your books using QuickBooks Online</li>
                                <li>Have the full ownership &amp; control of your books</li>
                                <li>Access your books anytime &amp; anywhere</li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="container mb-5">
                    <div class="row">
                        <div class="col-md-3 col-6 mb-xs-2rem">
                            <div class="about-box center-block wow zoomIn" data-wow-delay="400ms"
                                 title="  We support local enterprises, startups, and family-owned businesses, offering financial guidance and solutions to foster growth and sustainability."
                                 data-toggle="modal" data-target="#Modal1">
                                <div class="about-opacity-icon"><i class="fa fa-briefcase" aria-hidden="true"></i></div>
                                <div class="about-main-icon pb-4">
                                    <i class="fa fa-briefcase" aria-hidden="true"></i>
                                </div>
                                <h5 class="mb-0">Small Businesses</h5>
                                <div class="modal fade" id="Modal1"
                                     tabindex="-1" role="dialog"
                                     aria-labelledby="exampleModalLabel" aria-hidden="true">
                                    <div class="modal-dialog" role="document">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h6 class="modal-title" id="exampleModalLabel">Small Businesses</h6>
                                                <button type="button" class="close" data-dismiss="modal"
                                                        aria-label="Close">
                                                    <span aria-hidden="true">&times;</span>
                                                </button>
                                            </div>
                                            <div class="modal-body">
                                                <p class="text-center">
                                                    We support local enterprises, startups, and family-owned businesses,
                                                    offering financial guidance and solutions to foster growth and
                                                    sustainability.
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 col-6 mb-xs-2rem">
                            <div class="about-box center-block wow zoomIn" data-wow-delay="500ms"
                                 title="Our expertise in tech accounting and financial management assists technology companies, startups, and software developers, research & development credit x calculating."
                                 data-toggle="modal" data-target="#Modal2">
                                <div class="about-opacity-icon"><i class="fa fa-laptop-code" aria-hidden="true"></i>
                                </div>
                                <div class="about-main-icon pb-4">
                                    <i class="fa fa-laptop-code" aria-hidden="true"></i>
                                </div>
                                <h5 class="mb-0">Technology and IT</h5>
                            </div>
                            <div class="modal fade" id="Modal2"
                                 tabindex="-1" role="dialog"
                                 aria-labelledby="exampleModalLabel" aria-hidden="true">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h6 class="modal-title" id="exampleModalLabel">Technology and IT</h6>
                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                <span aria-hidden="true">&times;</span>
                                            </button>
                                        </div>
                                        <div class="modal-body">
                                            <p class="text-center">
                                                Our expertise in tech accounting and financial management assists
                                                technology
                                                companies, startups, and software developers, research & development
                                                credit
                                                calculating.
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 col-6 mb-xs-2rem">
                            <div class="about-box center-block wow zoomIn" data-wow-delay="600ms"
                                 title="We help healthcare professionals, medical practices, and healthcare organizations manage their finances efficiently, ensuring compliance with industry-specific regulations."
                                 data-toggle="modal" data-target="#Modal3">
                                <div class="about-opacity-icon"><i class="fa fa-chart-line" aria-hidden="true"></i>
                                </div>
                                <div class="about-main-icon pb-4">
                                    <i class="fa fa-hospital" aria-hidden="true"></i>
                                </div>
                                <h5 class="mb-0">Healthcare and Medical Practices</h5>
                                <div class="modal fade" id="Modal3"
                                     tabindex="-1" role="dialog"
                                     aria-labelledby="exampleModalLabel" aria-hidden="true">
                                    <div class="modal-dialog" role="document">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h6 class="modal-title" id="exampleModalLabel">Healthcare and Medical
                                                    Practices</h6>
                                                <button type="button" class="close" data-dismiss="modal"
                                                        aria-label="Close">
                                                    <span aria-hidden="true">&times;</span>
                                                </button>
                                            </div>
                                            <div class="modal-body">
                                                <p class="text-center">
                                                    We help healthcare professionals, medical practices, and healthcare
                                                    organizations manage their finances efficiently, ensuring compliance
                                                    with
                                                    industry-specific regulations.
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 col-6 mb-xs-2rem">
                            <div class="about-box center-block wow zoomIn" data-wow-delay="700ms"
                                 title="Our services aid real estate investors, property developers, and property management firms in optimizing their investments and property portfolios."
                                 data-toggle="modal" data-target="#Modal4">
                                <div class="about-opacity-icon"><i class="fa fa-money-bill-wave" aria-hidden="true"></i>
                                </div>
                                <div class="about-main-icon pb-4">
                                    <i class="fa fa-home" aria-hidden="true"></i>
                                </div>
                                <h5 class="mb-0">Real Estate and Property Management</h5>

                                <div class="modal fade" id="Modal4"
                                     tabindex="-1" role="dialog"
                                     aria-labelledby="exampleModalLabel" aria-hidden="true">
                                    <div class="modal-dialog" role="document">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h6 class="modal-title" id="exampleModalLabel">Real Estate and Property
                                                    Management</h6>
                                                <button type="button" class="close" data-dismiss="modal"
                                                        aria-label="Close">
                                                    <span aria-hidden="true">&times;</span>
                                                </button>
                                            </div>
                                            <div class="modal-body">
                                                <p class="text-center">
                                                    Our services aid real estate investors, property developers, and
                                                    property
                                                    management firms in optimizing their investments and property
                                                    portfolios.
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 col-6 mb-xs-2rem">
                            <div class="about-box center-block wow zoomIn" data-wow-delay="400ms"
                                 title="We assist retailers, both brick-and-mortar and online, in maximizing profitability and adapting to evolving consumer trends."
                                 data-toggle="modal" data-target="#Modal5">
                                <div class="about-opacity-icon"><i class="fa fa-briefcase" aria-hidden="true"></i></div>
                                <div class="about-main-icon pb-4">
                                    <i class="fa fa-shopping-basket" aria-hidden="true"></i>
                                </div>
                                <h5 class="mb-0">Retail and E-Commerce</h5>

                                <div class="modal fade" id="Modal5"
                                     tabindex="-1" role="dialog"
                                     aria-labelledby="exampleModalLabel" aria-hidden="true">
                                    <div class="modal-dialog" role="document">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h6 class="modal-title" id="exampleModalLabel">Retail and
                                                    E-Commerce</h6>
                                                <button type="button" class="close" data-dismiss="modal"
                                                        aria-label="Close">
                                                    <span aria-hidden="true">&times;</span>
                                                </button>
                                            </div>
                                            <div class="modal-body">
                                                <p class="text-center">
                                                    We assist retailers, both brick-and-mortar and online, in maximizing
                                                    profitability and adapting to evolving consumer trends.
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 col-6 mb-xs-2rem">
                            <div class="about-box center-block wow zoomIn" data-wow-delay="400ms"
                                 title="Our support extends to law firms, consulting agencies, and other professional service providers, helping them manage their finances and meet their growth objectives."
                                 data-toggle="modal" data-target="#Modal6">
                                <div class="about-opacity-icon"><i class="fa fa-briefcase" aria-hidden="true"></i></div>
                                <div class="about-main-icon pb-4">
                                    <i class="fa fa-server" aria-hidden="true"></i>
                                </div>
                                <h5 class="mb-0">Professional Services</h5>

                                <div class="modal fade" id="Modal6"
                                     tabindex="-1" role="dialog"
                                     aria-labelledby="exampleModalLabel" aria-hidden="true">
                                    <div class="modal-dialog" role="document">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h6 class="modal-title" id="exampleModalLabel">Professional
                                                    Services</h6>
                                                <button type="button" class="close" data-dismiss="modal"
                                                        aria-label="Close">
                                                    <span aria-hidden="true">&times;</span>
                                                </button>
                                            </div>
                                            <div class="modal-body">
                                                <p class="text-center">
                                                    Our support extends to law firms, consulting agencies, and other
                                                    professional service providers, helping them manage their finances
                                                    and meet
                                                    their growth objectives.
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 col-6 mb-xs-2rem">
                            <div class="about-box center-block wow zoomIn" data-wow-delay="400ms"
                                 title="We work with manufacturers and production companies to streamline operations, control costs, and improve financial performance."
                                 data-toggle="modal" data-target="#Modal7">
                                <div class="about-opacity-icon"><i class="fa fa-briefcase" aria-hidden="true"></i></div>
                                <div class="about-main-icon pb-4">
                                    <i class="fa fa-industry" aria-hidden="true"></i>
                                </div>
                                <h5 class="mb-0">Manufacturing and Production</h5>

                                <div class="modal fade" id="Modal7"
                                     tabindex="-1" role="dialog"
                                     aria-labelledby="exampleModalLabel" aria-hidden="true">
                                    <div class="modal-dialog" role="document">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h6 class="modal-title" id="exampleModalLabel">Manufacturing and
                                                    Production</h6>
                                                <button type="button" class="close" data-dismiss="modal"
                                                        aria-label="Close">
                                                    <span aria-hidden="true">&times;</span>
                                                </button>
                                            </div>
                                            <div class="modal-body">
                                                <p class="text-center">
                                                    We work with manufacturers and production companies to streamline
                                                    operations, control costs, and improve financial performance.
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 col-6 mb-xs-2rem">
                            <div class="about-box center-block wow zoomIn" data-wow-delay="400ms"
                                 title="We assist restaurants, hotels, and hospitality businesses in navigating the challenges of the industry and enhancing their financial sustainability."
                                 data-toggle="modal" data-target="#Modal8">
                                <div class="about-opacity-icon"><i class="fa fa-briefcase" aria-hidden="true"></i></div>
                                <div class="about-main-icon pb-4">
                                    <i class="fa fa-restroom" aria-hidden="true"></i>
                                </div>
                                <h5 class="mb-0">Hospitality and Restaurants</h5>

                                <div class="modal fade" id="Modal8"
                                     tabindex="-1" role="dialog"
                                     aria-labelledby="exampleModalLabel" aria-hidden="true">
                                    <div class="modal-dialog" role="document">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h6 class="modal-title" id="exampleModalLabel">Hospitality and
                                                    Restaurants</h6>
                                                <button type="button" class="close" data-dismiss="modal"
                                                        aria-label="Close">
                                                    <span aria-hidden="true">&times;</span>
                                                </button>
                                            </div>
                                            <div class="modal-body">
                                                <p class="text-center">
                                                    We assist restaurants, hotels, and hospitality businesses in
                                                    navigating the
                                                    challenges of the industry and enhancing their financial
                                                    sustainability.
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 col-6 mb-xs-2rem">
                            <div class="about-box center-block wow zoomIn" data-wow-delay="400ms"
                                 title=" We provide financial guidance to entertainment professionals, media companies, and artists, supporting their financial success in a dynamic industry."
                                 data-toggle="modal" data-target="#Modal9">
                                <div class="about-opacity-icon"><i class="fa fa-briefcase" aria-hidden="true"></i></div>
                                <div class="about-main-icon pb-4">
                                    <i class="fa fa-volume-up" aria-hidden="true"></i>
                                </div>
                                <h5 class="mb-0">Entertainment and Media</h5>
                                about-box
                                <div class="modal fade" id="Modal9"
                                     tabindex="-1" role="dialog"
                                     aria-labelledby="exampleModalLabel" aria-hidden="true">
                                    <div class="modal-dialog" role="document">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h6 class="modal-title" id="exampleModalLabel">Entertainment and
                                                    Media</h6>
                                                <button type="button" class="close" data-dismiss="modal"
                                                        aria-label="Close">
                                                    <span aria-hidden="true">&times;</span>
                                                </button>
                                            </div>
                                            <div class="modal-body">
                                                <p class="text-center">
                                                    We provide financial guidance to entertainment professionals, media
                                                    companies, and artists, supporting their financial success in a
                                                    dynamic
                                                    industry.
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>

                <div class="container" id="testimonials">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="elfsight-app-5654eb86-553e-4928-85b5-1bc30fe2a430" data-elfsight-app-lazy></div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </section>
    <!-- About ends -->

    <!-- Stats start -->
    <section class="half-section p-0 bg-change bg-blue">
        <h2 class="d-none">heading</h2>
        <div class="container-fluid">
            <div class="row align-items-center">
                <div class="col-lg-4 col-md-12 p-0 order-lg-2">
                    <div class="hover-effect text-right">
                        <img alt="stats" src="<?php echo e(asset('afnan.jpg')); ?>" class="about-img">
                    </div>
                </div>

                <div class="col-lg-6 col-md-12 p-lg-0">
                    <div class="split-container-setting stats style-three">
                        <div class="main-title mb-2 text-lg-left wow fadeIn" data-wow-delay="300ms">
                            <h2 class="mt-3 p-0 mb-0"> Afnan Abduljaber CPA, MSA</h2>
                        </div>
                        <p style="font-size: 16px;color: white;text-align: justify">
                            Afnan Abduljaber has been providing clients with personalized tax preparation and accounting
                            services.
                            Afnan is a Certified Public Accountant and hold a Master’s in Accounting degree from
                            Wayne State University.
                            Afnan achieved a 4.00/4.00 GPA in four on-campus Graduate Accounting
                            Courses in one semester.
                            In her free time, Afnan stays active and enjoys outdoor activities and
                            socializing events.
                            With years of certified training, Afnan has the necessary skills,
                            qualifications and expertise to get the job done and commit at its highest quality. Whether
                            you’re looking for a tax planner or a book-keeping adviser, she can guide you every step of
                            the
                            way and help you make the right decisions.
                            Afnan is a firm believer in an open line of
                            communications with her current and prospective clients to understand their unique concerns
                            and
                            offer the best outcome.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Stats ends -->



    <section id="request" class="m-0 p-0 pb-5 pt-5">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <h4 class="text-center h-d">Services</h4>
                    <div class="text-center mb-3">
                        What is my services
                    </div>
                </div>
                <div class="col-12">
                    <nav>
                        <div class="nav nav-tabs nav-fill" id="nav-tab" role="tablist">
                            <a class="nav-item nav-link active" id="nav-home-tab" data-toggle="tab" href="#nav-home"
                               role="tab" aria-controls="nav-home" aria-selected="true">Tax Planning & Preparation</a>
                            <a class="nav-item nav-link" id="nav-profile-tab" data-toggle="tab" href="#nav-profile"
                               role="tab" aria-controls="nav-profile" aria-selected="false">Bookkeeping & Payroll
                                Services</a>
                            <a class="nav-item nav-link" id="nav-contact-tab" data-toggle="tab" href="#nav-contact"
                               role="tab" aria-controls="nav-contact" aria-selected="false">Entity Formation & S-corp Election</a>
                            <a class="nav-item nav-link" id="nav-contact-tab" data-toggle="tab" href="#nav-contact2"
                               role="tab" aria-controls="nav-contact" aria-selected="false">Tax Organizer/Questionnaire</a>
                            <a class="nav-item nav-link" id="nav-contact-tab" data-toggle="tab" href="#nav-iris"
                               role="tab" aria-controls="nav-contact" aria-selected="false">IRS representation</a>
                        </div>
                    </nav>
                    <div class="tab-content py-3 px-3 px-sm-0" id="nav-tabContent">
                        <div class="tab-pane fade show active" id="nav-home" role="tabpanel"
                             aria-labelledby="nav-home-tab">
                            <p class="ol-explain"><b>Small businesses can explore various tax-saving areas to reduce their
                                    tax liabilities and maximize their after-tax income. Here are some key tax-saving
                                    strategies and areas that small businesses should consider:</b></p>
                            <ol class="ol-list">
                                <li>Qualified Business Income Deduction (QBI): Under the Tax Cuts and Jobs Act (TCJA),
                                    eligible small businesses may qualify for a deduction of up to 20% of their
                                    qualified business income. Understanding and optimizing this deduction can result in
                                    significant tax savings.
                                </li>
                                <li>Business Entity Selection: Choosing the right business structure (e.g., sole
                                    proprietorship, partnership, S-Corp, C-Corp) can impact your tax liability. Consult
                                    with a CPA to determine the most tax-efficient entity for your business.
                                </li>
                                <li>Expense Deductions: Ensure you&apos;re taking advantage of all available business
                                    expense deductions. Common deductions include rent, utilities, supplies, insurance,
                                    and business-related travel.
                                </li>
                                <li>Home Office Deduction: If you work from home, you may be eligible for a home office
                                    deduction. This can include a portion of your rent or mortgage interest, utilities,
                                    and maintenance expenses.
                                </li>
                                <li>Depreciation and Section 179: Consider strategies for depreciating assets and
                                    utilizing Section 179 expensing to accelerate deductions for equipment, machinery,
                                    and property.
                                </li>
                                <li>Augusta Rule: Homeowners who rent out their primary residence to their businesses
                                    for 14 days or less in a calendar year do not need to report the rental income on
                                    their federal tax return.
                                </li>
                                <li>Hiring Tax Credits: Take advantage of tax credits available for hiring specific
                                    groups, such as veterans or individuals from economically disadvantaged backgrounds.
                                </li>
                                <li>Hiring your child</li>
                                <li>Cost segregation studies: a detailed analysis of a commercial or residential
                                    property&apos;s components and assets to accelerate depreciation for income tax
                                    purpose
                                </li>
                            </ol>
                        </div>
                        <div class="tab-pane fade" id="nav-profile" role="tabpanel" aria-labelledby="nav-profile-tab">
                            <div class="row">
                                <div class="col-md-12">
                                    <p class="ol-explain"><b>Our Accounting and Bookkeeping Services:</b></p>
                                    <ol class="ol-list">
                                        <li><strong>Financial Record Keeping:</strong> We handle the tracking and recording of all your financial transactions, ensuring accuracy and compliance with accounting standards.</li>
                                        <li><strong>Bank Reconciliation:</strong> We reconcile your bank statements with your financial records, uncovering discrepancies and ensuring your accounts are in order.</li>
                                        <li><strong>Payroll Services:</strong> Accurate and on-time payroll processing, including tax withholding and reporting, to ensure your employees are paid correctly.</li>
                                        <li><strong>Financial Reporting:</strong> We provide clear, concise, and timely financial reports that give you valuable insights into your financial health, helping you make informed decisions.</li>
                                        <li><strong>Budgeting and Forecasting:</strong> We assist you in creating budgets and financial forecasts that guide your business strategy and help you plan for the future.</li>
                                        <li><strong>Tax Planning and Compliance: </strong>Our expertise extends to tax planning and compliance, minimizing your tax liabilities while ensuring full adherence to tax laws and regulations.</li>
                                        <li><strong>Cloud-Based Accounting Solutions: </strong>We leverage cutting-edge accounting software to provide real-time access to your financial data, promoting efficiency and collaboration.</li>
                                    </ol>
                                    <p class="ol-explain"><b>Why Choose [Your CPA Firm Name] for Accounting and Bookkeeping?</b></p>
                                    <ul class="ol-list">
                                        <li><strong>Expertise: </strong>Our team of certified accountants and CPAs brings a wealth of knowledge and experience to your financial management.</li>
                                        <li><strong>Customized Solutions: </strong>We tailor our services to your unique needs, ensuring that you receive the support and guidance that aligns with your goals.</li>
                                        <li><strong>Accuracy and Compliance: </strong>We prioritize accuracy and compliance with accounting and tax regulations, giving you peace of mind.</li>
                                        <li><strong>Time Savings:</strong> Outsourcing your accounting and bookkeeping tasks to us frees up your time to focus on growing your business or managing your personal finances.</li>
                                        <li><strong>Financial Clarity: </strong>With our services, you gain a clear picture of your financial health, enabling better decision-making and financial planning.</li>
                                        <li><strong>Proactive Guidance:</strong> We&apos;re not just number crunchers; we&apos;re strategic advisors who help you navigate financial challenges and seize opportunities.</li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="nav-contact" role="tabpanel" aria-labelledby="nav-contact-tab">
                            <p class="ol-explain"><b>Unlocking Tax Benefits: Converting to an S-Corp</b></p>
                            <ul class="ol-list">
                                <li>We provide S-Corp conversion tax-savings sheet in numbers&nbsp;</li>
                                <li>We assist with owner&rsquo;s reasonable salary calculations&nbsp;</li>
                                <li>We file form 2553 with the IRS for the election</li>
                                <li>Owners&rsquo; Basis calculation and distributions</li>
                            </ul>
                        </div>
                        <div class="tab-pane fade" id="nav-contact2" role="tabpanel" aria-labelledby="nav-contact-tab">
                            <object data="<?php echo e(\App\Models\SiteSetting::getFileURL($site_setting->tax_questionnaire)); ?>" type="application/pdf" width="100%" height="500px">
                                <p>Unable to display PDF file. <a href="<?php echo e(\App\Models\SiteSetting::getFileURL($site_setting->tax_questionnaire)); ?>">Download</a> instead.</p>
                            </object>
                        </div>
                        <div class="tab-pane fade" id="nav-iris" role="tabpanel" aria-labelledby="nav-contact-tab">

                            <b>Key aspects of IRS representation services include:</b>
<br/>
                            <ol class="ol-list"><li>Audit Support: Professionals assist clients during IRS audits, guiding them through the process, gathering necessary documentation, and representing their interests before the IRS.</li>
                            <li>Communication with the IRS: Representatives handle all communication with the IRS on behalf of their clients. This includes responding to notices, inquiries, and requests for information.</li>
                            <li>Negotiation and Settlement: If a client owes back taxes, representatives can negotiate with the IRS to establish a payment plan or settle for a reduced amount through offers in compromise.</li>
                            <li>Appeals: In cases of disputes, IRS representatives can file appeals and present arguments to challenge IRS decisions, ensuring clients have a fair opportunity to address any discrepancies.</li>
                            <li>Tax Compliance: Professionals assist clients in understanding and meeting their tax obligations, providing advice on tax planning, deductions, and credits to minimize future tax liabilities.</li>
                            <li>Legal Expertise: Tax attorneys within IRS representation services can offer legal counsel in complex tax situations, providing a deeper understanding of tax law and potential legal implications.</li>
                            <li>Choosing an experienced and reputable IRS representation service is crucial for individuals and businesses facing tax challenges. It can alleviate the stress of dealing with the IRS and increase the likelihood of achieving favorable outcomes.</li></ol>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </section>

    <!-- Request Boxes start -->
    <section class="pt-0">
        <div class="container">
            <div class="row">
                <div class="col-lg-3 col-sm-6 col-12">
                    <div class="process-box text-sm-left mb-4 mb-lg-0">
                        <span class="pro-step d-inline-block"><i class="fa fa-server"></i></span>
                        <h5 class="font-weight-normal color-black mt-25px mb-15px text-capitalize">setup meeting</h5>
                        <p class="font-weight-normal">Lorem dapibus, tortor eget turpis auctor, convallis odio ac.</p>
                    </div>
                </div>
                <div class="col-lg-3 col-sm-6 col-12">
                    <div class="process-box text-sm-left mb-4 mb-lg-0">
                        <span class="pro-step d-inline-block"><i class="fa fa-layer-group"></i></span>
                        <h5 class="font-weight-normal color-black mt-25px mb-15px text-capitalize">consultancy</h5>
                        <p class="font-weight-normal">Etiam luctus, lacus maximus elementum dapibus felis.</p>
                    </div>
                </div>
                <div class="col-lg-3 col-sm-6 col-12">
                    <div class="process-box text-sm-left mb-4 mb-sm-0">
                        <span class="pro-step d-inline-block"><i class="fa fa-file"></i></span>
                        <h5 class="font-weight-normal color-black mt-25px mb-15px text-capitalize">execution</h5>
                        <p class="font-weight-normal">Maecenas fringilla molestie elit, maximus dui eleifend quis.</p>
                    </div>
                </div>
                <div class="col-lg-3 col-sm-6 col-12">
                    <div class="process-box text-sm-left mb-0">
                        <span class="pro-step d-inline-block"><i class="fa fa-award"></i></span>
                        <h5 class="font-weight-normal color-black mt-25px mb-15px text-capitalize">completion</h5>
                        <p class="font-weight-normal">Pellentesque habitant morbi tristique senectus et malesuada.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Request Boxes end -->

    <!-- Request start -->
    <section  class="bg-light-gray half-section p-0">
        <div class="container-fluid">
            <div class="row align-items-center">
                <div class="col-lg-6 col-md-12 p-0">
                    <div class="owl-carousel owl-theme owl-split">
                        <div class="item">
                            <div class="image split-blog-scale">
                                <img alt="request" src="consulting/img/split-request.jpg" class="about-img">
                            </div>
                        </div>
                        <div class="item">
                            <div class="image split-blog-scale">
                                <img alt="request" src="consulting/img/split-request2.jpg" class="about-img">
                            </div>
                        </div>
                        <div class="item">
                            <div class="image split-blog-scale">
                                <img alt="request" src="consulting/img/split-request3.jpg" class="about-img">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 col-md-12 split-box-container-setting text-center p-md-0">
                    <div class="split-container-setting">
                        <div class="main-title text-center text-lg-left mb-lg-4 wow fadeIn" data-wow-delay="300ms">
                            <h5> Have any questions? </h5>
                            <h2 class="mb-2rem"> Request a <b>call back</b></h2>
                            <h5> I would like to discuss: </h5>
                        </div>

                        <div class="request-form">
                            <form class="request-form-outer" id="contact-service-data" method="POST"
                                  action="<?php echo e(route('call-back')); ?>">
                                <div class="row">
                                    <div class="col-sm-12" id="result"></div>
                                    <div class="col-md-12 col-sm-12">
                                        <div class="request-form-textfield pb-4">
                                            <select class="form-control" title="service" name="service" id="services"
                                                    required>
                                                <option value="Select Service">Select Service</option>
                                                <option value="Tax Preparation">Tax Preparation</option>
                                                <option value="Entity Formation">Entity Formation</option>
                                                <option value="Quarterly Taxes">Quarterly Taxes</option>
                                                <option value="Bookkeeping">Bookkeeping</option>
                                                <option value="Payroll">Payroll</option>
                                                <option value="Payroll">IRS representation</option>
                                                <option value="Other">Other</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-12 col-sm-12">
                                        <div class="request-form-textfield pb-4">
                                            <input type="text" placeholder="Name" class="form-control mb-0" required=""
                                                   id="name" name="name">
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-sm-12">
                                        <div class="request-form-textfield pb-4">
                                            <input type="tel" placeholder="Contact No" class="form-control mb-0"
                                                   required=""
                                                   id="phone" name="phone">
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-sm-12">
                                        <div class="request-form-textfield pb-4">
                                            <input type="email" placeholder="Email" class="form-control mb-0"
                                                   required=""
                                                   id="email" name="email">
                                        </div>
                                    </div>
                                    <?php echo csrf_field(); ?>
                                    <div class="col-lg-12 pt-xs-25px text-lg-left text-center">
                                        <button type="submit"
                                                class="btn-setting btn-scale btn-blue text-white contact_btn">request
                                            now
                                        </button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </section>
    <!--Request ends-->


    <!-- Blog start -->
    <section id="blog" class="half-section p-0 bg-light-gray">
        <h2 class="d-none">heading</h2>
        <div class="container-fluid">
            <div class="row align-items-center">

                <div class="col-lg-6 col-md-12 p-0 order-lg-2">
                    <div class="owl-carousel owl-theme owl-split">
                        <?php
                        $bb = \App\Models\Blog::orderBy('id', 'desc')->skip(0)->take(3)->get();
                        $last_blog = \App\Models\Blog::orderBy('id', 'desc')->first();
                        ?>
                        <?php $__currentLoopData = $bb; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <div class="item">
                                <div class="hover-effect">
                                    <img alt="blog" src="<?php echo e(Voyager::image($b->image)); ?>" class="about-img">
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>

                <div class="col-lg-6 col-md-12 p-lg-0">
                    <div class="split-container-setting style-three text-center">
                        <div class="main-title mb-5 wow fadeIn" data-wow-delay="300ms">
                            <h5 class="font-18 text-blue"> <?php echo $last_blog->date; ?></h5>
                            <h2 class="mb-0 font-weight-normal">  <?php echo $last_blog->title; ?></h2>
                        </div>
                        <div class="color-black mb-5" style="max-height: 100px;min-height: 100px;overflow: hidden">
                            <?php echo $last_blog->content; ?>

                        </div>

                        <a href="<?php echo e(route('blogs')); ?>" class="btn-setting btn-scale btn-blue text-white">Explore</a>

                    </div>
                </div>

            </div>
        </div>
    </section>
    <!-- Blog ends -->

    <!-- Brands starts -->
    <section class="bg-green brand-transform-padding">
        <div class="section-padding2">
            <h2 class="d-none">heading</h2>
            <div class="container">
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
            </div>
        </div>
    </section>
    <!-- Brands ends -->

    <!-- Contact & Map starts -->
    <section id="contact" class="p-0 contact-transform position-absolute w-100">
        <div class="container contact-shadow">
            <div class="row mx-lg-0">
                <div class="col-lg-6 col-md-6 col-sm-12 p-0">
                    <div class="contact-box box-shadow-contact pt-5">
                        <div class="main-title text-center text-md-left mb-4">
                            <h2 class="font-weight-normal">Contact Us </h2>
                        </div>

                        <div class="text-center text-md-left">

                            <!--Address-->
                            <p class="mb-3">
                                <b>Address:</b> <?php echo $site_setting->address; ?>

                            </p>

                            <!--Phone-->
                            <p class="mb-3">
                                
                                
                                <b> Mobile:</b> <?php echo e($site_setting->mobile); ?>

                            </p>

                            <!--Email-->
                            <p class="mb-3"><b>Email:</b> <a href="mailto:<?php echo e($site_setting->email); ?>"
                                                             class="color-black"><?php echo e($site_setting->email); ?></a>
                                <br>
                                
                                
                            </p>

                            <!--Timing-->
                            <p class="mb-3"><?php echo e($site_setting->work_times); ?></p>

                            <!--Social Icon-->
                            <div class="address-social black">
                                <ul class="list-unstyled">
                                    <?php if(strlen($site_setting->facebook)>5): ?>
                                        <li><a class="facebook-bg-hvr ml-0" href="<?php echo e($site_setting->facebook); ?>"><i
                                                    class="fab fa-facebook-f" aria-hidden="true"></i></a></li>
                                    <?php endif; ?>
                                    <?php if(strlen($site_setting->twitter)>5): ?>
                                        <li><a class="twitter-bg-hvr" href="<?php echo e($site_setting->twitter); ?>"><i
                                                    class="fab fa-twitter"
                                                    aria-hidden="true"></i></a>
                                        </li>

                                    <?php endif; ?>
                                    <?php if(strlen($site_setting->gmail)>5): ?>
                                        <li><a class="google-bg-hvr" href="<?php echo e($site_setting->gmail); ?>"><i
                                                    class="fab fa-google"
                                                    aria-hidden="true"></i></a>
                                        </li>

                                    <?php endif; ?>
                                    <?php if(strlen($site_setting->linkedin)>5): ?>
                                        <li><a class="linkedin-bg-hvr" href="<?php echo e($site_setting->linkedin); ?>"><i
                                                    class="fab fa-linkedin-in"
                                                    aria-hidden="true"></i></a>
                                        </li>

                                    <?php endif; ?>
                                    <?php if(strlen($site_setting->tiktok)>5): ?>
                                        <li><a class="tiktok-bg-hvr" href="<?php echo e($site_setting->tiktok); ?>">
                                                <svg xmlns="http://www.w3.org/2000/svg"
                                                     style="width: 19px;"
                                                     viewBox="0 0 448 512">
                                                    <path
                                                        d="M448 209.9a210.1 210.1 0 0 1 -122.8-39.3V349.4A162.6 162.6 0 1 1 185 188.3V278.2a74.6 74.6 0 1 0 52.2 71.2V0l88 0a121.2 121.2 0 0 0 1.9 22.2h0A122.2 122.2 0 0 0 381 102.4a121.4 121.4 0 0 0 67 20.1z"/>
                                                </svg>
                                            </a>
                                        </li>

                                    <?php endif; ?>
                                    <?php if(strlen($site_setting->instagram)>5): ?>
                                        <li><a class="instagram-bg-hvr mr-0" href="<?php echo e($site_setting->instagram); ?>"><i
                                                    class="fab fa-instagram" aria-hidden="true"></i></a></li>
                                    <?php endif; ?>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6 col-sm-12 p-0 col-map box-shadow-map">
                    <div class="contact-box box-shadow-contact pt-5">
                        <div class="container">
                            <form class="request-form-outer" id="contact-form-data" method="POST"
                                  action="<?php echo e(route('contact-us')); ?>">
                                <?php echo csrf_field(); ?>
                                <div class="row">
                                    <div class="col-sm-12" id="result"></div>
                                    <div class="col-md-12 col-sm-12">
                                        <div class="request-form-textfield pb-4">
                                            <input type="text" placeholder="Name" class="form-control mb-0" required=""
                                                   id="name" name="name">
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-sm-12">
                                        <div class="request-form-textfield pb-4">
                                            <input type="tel" placeholder="Contact No" class="form-control mb-0"
                                                   required=""
                                                   id="phone" name="phone">
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-sm-12">
                                        <div class="request-form-textfield pb-4">
                                            <input type="email" placeholder="Email" class="form-control mb-0"
                                                   required=""
                                                   id="email" name="email">
                                        </div>
                                    </div>
                                    <div class="col-md-12 col-sm-12">
                                        <div class="request-form-textfield pb-4">
                                    <textarea
                                        placeholder="Reason for the contact or description"
                                        class="form-control mb-0" required=""
                                        name="text"
                                        id="userReason"
                                    ></textarea>
                                        </div>
                                    </div>
                                    <div class="col-lg-12 pt-xs-25px text-lg-left text-center">
                                        <button type="submit"
                                                class="btn-setting btn-scale btn-blue text-white contact_btn">Contact
                                            now
                                        </button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <iframe
                    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d11594.228498423003!2d-83.68932927791784!3d42.249329227021214!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x883caf2dbe6320e9%3A0xbb9d5b6c6cb6e773!2scarpenter%20RD.%20Proffessional%20Building%2C%202512%20Carpenter%20Rd%2C%20Ann%20Arbor%2C%20MI%2048108%2C%20USA!5e0!3m2!1sen!2sae!4v1705615300990!5m2!1sen!2sae"
                    width="600" height="200" style="border:0;border-radius: 0 0 20px 20px;" allowfullscreen=""
                    loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
            </div>
        </div>
    </section>



    <!-- Contact & Map ends -->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script src="https://static.elfsight.com/platform/platform.js" data-use-service-core defer></script>
    <script>
        setTimeout(() => {
            $(".jdVdAT").children().last().remove();
        }, 5000);

        $(".about-box").on({
            mouseenter: function () {
                $(this).addClass('active');
            },
            mouseleave: function () {
                $(this).removeClass('active');
            }
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp64\www\abdulcpa\resources\views/index.blade.php ENDPATH**/ ?>