<!-- Favicon -->
<link rel="icon" href="<?php echo e(asset('consulting/img/favicon.ico')); ?>">
<!-- Bundle -->
<link rel="stylesheet" href="<?php echo e(asset('vendor/css/bundle.min.css')); ?>">
<!-- Plugin Css -->
<link rel="stylesheet" href="<?php echo e(asset('vendor/css/jquery.fancybox.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('vendor/css/owl.carousel.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('vendor/css/swiper.min.css')); ?>">

<link rel="stylesheet" href="<?php echo e(asset('vendor/css/cubeportfolio.min.css')); ?>">
<!-- Revolution Slider CSS Files -->
<link rel="stylesheet" href="<?php echo e(asset('consulting/css/navigation.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('consulting/css/settings.css')); ?>">
<!-- Slick CSS Files -->
<link rel="stylesheet" href="<?php echo e(asset('vendor/css/slick.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('vendor/css/slick-theme.css')); ?>">
<!-- Select -->
<link rel="stylesheet" href="<?php echo e(asset('vendor/css/select2.min.css')); ?>">
<!-- Style Sheet -->
<link rel="stylesheet" href="<?php echo e(asset('consulting/css/style.css')); ?>">
<!-- Custom Style CSS File -->
<link rel="stylesheet" href="<?php echo e(asset('consulting/css/custom.css')); ?>">
<?php /**PATH E:\wamp64\www\abdulcpa\resources\views/css.blade.php ENDPATH**/ ?>